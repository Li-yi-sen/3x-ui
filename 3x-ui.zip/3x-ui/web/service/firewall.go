package service

import (
	"fmt"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"

	"x-ui/logger"
)

type FirewallService struct{}

type FirewallType string

const (
	FirewallTypeFirewalld FirewallType = "firewalld"
	FirewallTypeUfw       FirewallType = "ufw"
	FirewallTypeNone      FirewallType = "none"
)

type FirewallStatus struct {
	Type        FirewallType `json:"type"`
	Active      bool         `json:"active"`
	OpenPorts   []string     `json:"openPorts"`
	LastUpdated time.Time    `json:"lastUpdated"`
}

// DetectFirewall 检测系统中的防火墙类型
func (s *FirewallService) DetectFirewall() FirewallType {
	if s.commandExists("firewall-cmd") {
		return FirewallTypeFirewalld
	} else if s.commandExists("ufw") {
		return FirewallTypeUfw
	}
	return FirewallTypeNone
}

// commandExists 检查命令是否存在
func (s *FirewallService) commandExists(cmd string) bool {
	_, err := exec.LookPath(cmd)
	return err == nil
}

// IsFirewallActive 检查防火墙是否激活
func (s *FirewallService) IsFirewallActive() (bool, error) {
	fwType := s.DetectFirewall()
	
	switch fwType {
	case FirewallTypeFirewalld:
		cmd := exec.Command("systemctl", "is-active", "--quiet", "firewalld")
		err := cmd.Run()
		return err == nil, nil
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "status")
		output, err := cmd.Output()
		if err != nil {
			return false, err
		}
		return strings.Contains(string(output), "Status: active"), nil
	default:
		return false, fmt.Errorf("不支持的防火墙类型: %s", fwType)
	}
}

// EnableFirewall 启用防火墙
func (s *FirewallService) EnableFirewall() error {
	fwType := s.DetectFirewall()
	
	switch fwType {
	case FirewallTypeFirewalld:
		cmd := exec.Command("systemctl", "enable", "--now", "firewalld")
		return cmd.Run()
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "--force", "enable")
		return cmd.Run()
	default:
		return fmt.Errorf("不支持的防火墙类型: %s", fwType)
	}
}

// AddPort 添加端口到防火墙（完整流程，包含立即生效）
func (s *FirewallService) AddPort(port int, protocol string) error {
	if protocol == "" {
		protocol = "tcp"
	}
	
	fwType := s.DetectFirewall()
	
	switch fwType {
	case FirewallTypeFirewalld:
		// 添加永久规则
		cmd1 := exec.Command("firewall-cmd", "--permanent", "--add-port", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd1.Run(); err != nil {
			return fmt.Errorf("添加永久规则失败: %v", err)
		}
		
		// 重新加载配置
		cmd2 := exec.Command("firewall-cmd", "--reload")
		if err := cmd2.Run(); err != nil {
			return fmt.Errorf("重新加载防火墙配置失败: %v", err)
		}
		
		// 验证端口是否生效
		cmd3 := exec.Command("firewall-cmd", "--query-port", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd3.Run(); err != nil {
			return fmt.Errorf("端口 %d/%s 未能正确激活", port, protocol)
		}
		
		logger.Infof("端口 %d/%s 已成功通过 firewalld 激活", port, protocol)
		return nil
		
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "allow", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd.Run(); err != nil {
			return fmt.Errorf("ufw 添加端口失败: %v", err)
		}
		
		logger.Infof("端口 %d/%s 已成功通过 ufw 激活", port, protocol)
		return nil
		
	default:
		return fmt.Errorf("不支持的防火墙类型: %s", fwType)
	}
}

// RemovePort 从防火墙移除端口
func (s *FirewallService) RemovePort(port int, protocol string) error {
	if protocol == "" {
		protocol = "tcp"
	}
	
	fwType := s.DetectFirewall()
	
	switch fwType {
	case FirewallTypeFirewalld:
		cmd1 := exec.Command("firewall-cmd", "--permanent", "--remove-port", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd1.Run(); err != nil {
			return fmt.Errorf("移除永久规则失败: %v", err)
		}
		
		cmd2 := exec.Command("firewall-cmd", "--reload")
		if err := cmd2.Run(); err != nil {
			return fmt.Errorf("重新加载防火墙配置失败: %v", err)
		}
		
		logger.Infof("端口 %d/%s 已从 firewalld 移除", port, protocol)
		return nil
		
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "delete", "allow", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd.Run(); err != nil {
			return fmt.Errorf("ufw 移除端口失败: %v", err)
		}
		
		logger.Infof("端口 %d/%s 已从 ufw 移除", port, protocol)
		return nil
		
	default:
		return fmt.Errorf("不支持的防火墙类型: %s", fwType)
	}
}

// GetOpenPorts 获取当前开放的端口列表
func (s *FirewallService) GetOpenPorts() ([]string, error) {
	fwType := s.DetectFirewall()
	
	switch fwType {
	case FirewallTypeFirewalld:
		cmd := exec.Command("firewall-cmd", "--list-ports")
		output, err := cmd.Output()
		if err != nil {
			return nil, fmt.Errorf("获取firewalld端口列表失败: %v", err)
		}
		
		portsStr := strings.TrimSpace(string(output))
		if portsStr == "" {
			return []string{}, nil
		}
		
		return strings.Split(portsStr, " "), nil
		
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "status")
		output, err := cmd.Output()
		if err != nil {
			return nil, fmt.Errorf("获取ufw状态失败: %v", err)
		}
		
		// 解析ufw输出
		lines := strings.Split(string(output), "\n")
		var ports []string
		portRegex := regexp.MustCompile(`^(\d+)(/\w+)?\s+ALLOW`)
		
		for _, line := range lines {
			if matches := portRegex.FindStringSubmatch(strings.TrimSpace(line)); matches != nil {
				ports = append(ports, matches[1]+matches[2])
			}
		}
		
		return ports, nil
		
	default:
		return nil, fmt.Errorf("不支持的防火墙类型: %s", fwType)
	}
}

// GetFirewallStatus 获取防火墙状态
func (s *FirewallService) GetFirewallStatus() (*FirewallStatus, error) {
	fwType := s.DetectFirewall()
	active, err := s.IsFirewallActive()
	if err != nil {
		return nil, err
	}
	
	var ports []string
	if active {
		ports, err = s.GetOpenPorts()
		if err != nil {
			logger.Warningf("获取端口列表失败: %v", err)
			ports = []string{}
		}
	}
	
	return &FirewallStatus{
		Type:        fwType,
		Active:      active,
		OpenPorts:   ports,
		LastUpdated: time.Now(),
	}, nil
}

// ValidatePort 验证端口号是否有效
func (s *FirewallService) ValidatePort(port int) error {
	if port < 1 || port > 65535 {
		return fmt.Errorf("端口号必须在1-65535之间")
	}
	return nil
}

// ValidatePortString 验证端口字符串并转换为整数
func (s *FirewallService) ValidatePortString(portStr string) (int, error) {
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return 0, fmt.Errorf("无效的端口号: %s", portStr)
	}
	
	if err := s.ValidatePort(port); err != nil {
		return 0, err
	}
	
	return port, nil
}

// ActivateInboundPort 激活入站规则端口（主要接口）
func (s *FirewallService) ActivateInboundPort(port int) error {
	if err := s.ValidatePort(port); err != nil {
		return err
	}
	
	// 确保防火墙已启用
	active, err := s.IsFirewallActive()
	if err != nil {
		return fmt.Errorf("检查防火墙状态失败: %v", err)
	}
	
	if !active {
		logger.Infof("防火墙未激活，正在启用...")
		if err := s.EnableFirewall(); err != nil {
			return fmt.Errorf("启用防火墙失败: %v", err)
		}
	}
	
	// 添加端口
	return s.AddPort(port, "tcp")
} 
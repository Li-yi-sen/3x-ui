#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
blue='\033[0;34m'
yellow='\033[0;33m'
plain='\033[0m'

# 获取脚本所在目录的绝对路径
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$(dirname "$SCRIPT_DIR")")"
LOCAL_RESOURCES_DIR="$BASE_DIR/local-resources"

# 检查是否为root用户
[[ $EUID -ne 0 ]] && echo -e "${red}致命错误: ${plain} 请使用 root 权限运行此脚本\n" && exit 1

# 检查操作系统
if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    release=$ID
elif [[ -f /usr/lib/os-release ]]; then
    source /usr/lib/os-release
    release=$ID
else
    echo -e "${red}检查服务器操作系统失败，请联系作者!${plain}" >&2
    exit 1
fi

echo -e "${green}---------->>>>>目前服务器的操作系统为: $release${plain}"

# 架构检测
arch() {
    case "$(uname -m)" in
        x86_64 | x64 | amd64 ) echo 'amd64' ;;
        i*86 | x86 ) echo '386' ;;
        armv8* | armv8 | arm64 | aarch64 ) echo 'arm64' ;;
        armv7* | armv7 | arm ) echo 'armv7' ;;
        armv6* | armv6 ) echo 'armv6' ;;
        armv5* | armv5 ) echo 'armv5' ;;
        s390x) echo 's390x' ;;
        *) echo -e "${green}不支持的CPU架构! ${plain}" && exit 1 ;;
    esac
}

echo -e "${yellow}---------->>>>>当前系统的架构为: $(arch)${plain}"

# GLIBC版本检查
check_glibc_version() {
    glibc_version=$(ldd --version | head -n1 | awk '{print $NF}')
    required_version="2.32"
    if [[ "$(printf '%s\n' "$required_version" "$glibc_version" | sort -V | head -n1)" != "$required_version" ]]; then
        echo -e "${red}------>>>GLIBC版本 $glibc_version 太旧了！ 要求2.32或以上版本${plain}"
        echo -e "${green}-------->>>>请升级到较新版本的操作系统以便获取更高版本的GLIBC${plain}"
        exit 1
    fi
    echo -e "${green}-------->>>>GLIBC版本： $glibc_version（符合高于2.32的要求）${plain}"
}

check_glibc_version

# 操作系统版本检查
os_version=$(grep -i version_id /etc/os-release | cut -d \" -f2 | cut -d . -f1)

if [[ "${release}" == "centos" ]]; then
    if [[ ${os_version} -lt 8 ]]; then
        echo -e "${red} 请使用 CentOS 8 或更高版本 ${plain}\n" && exit 1
    fi
elif [[ "${release}" == "ubuntu" ]]; then
    if [[ ${os_version} -lt 20 ]]; then
        echo -e "${red} 请使用 Ubuntu 20 或更高版本!${plain}\n" && exit 1
    fi
elif [[ "${release}" == "fedora" ]]; then
    if [[ ${os_version} -lt 36 ]]; then
        echo -e "${red} 请使用 Fedora 36 或更高版本!${plain}\n" && exit 1
    fi
elif [[ "${release}" == "debian" ]]; then
    if [[ ${os_version} -lt 11 ]]; then
        echo -e "${red} 请使用 Debian 11 或更高版本 ${plain}\n" && exit 1
    fi
elif [[ "${release}" == "almalinux" ]]; then
    if [[ ${os_version} -lt 9 ]]; then
        echo -e "${red} 请使用 AlmaLinux 9 或更高版本 ${plain}\n" && exit 1
    fi
elif [[ "${release}" == "rocky" ]]; then
    if [[ ${os_version} -lt 9 ]]; then
        echo -e "${red} 请使用 RockyLinux 9 或更高版本 ${plain}\n" && exit 1
    fi
elif [[ "${release}" == "oracle" ]]; then
    if [[ ${os_version} -lt 8 ]]; then
        echo -e "${red} 请使用 Oracle Linux 8 或更高版本 ${plain}\n" && exit 1
    fi
else
    echo -e "${red}此脚本不支持您的操作系统。${plain}\n"
    echo "请确保您使用的是以下受支持的操作系统之一："
    echo "- Ubuntu 20.04+"
    echo "- Debian 11+"
    echo "- CentOS 8+"
    echo "- Fedora 36+"
    echo "- Arch Linux"
    echo "- Manjaro"
    echo "- Armbian"
    echo "- Alpine Linux"
    echo "- AlmaLinux 9+"
    echo "- Rocky Linux 9+"
    echo "- Oracle Linux 8+"
    echo "- OpenSUSE Tumbleweed"
    exit 1
fi

# 安装基础软件包
install_base() {
    case "${release}" in
        ubuntu | debian | armbian)
            apt-get update && apt-get install -y -q wget curl tar tzdata
            ;;
        centos | rhel | almalinux | rocky | ol)
            yum -y update && yum install -y -q wget curl tar tzdata
            ;;
        fedora | amzn | virtuozzo)
            dnf -y update && dnf install -y -q wget curl tar tzdata
            ;;
        arch | manjaro | parch)
            pacman -Syu && pacman -Syu --noconfirm wget curl tar tzdata
            ;;
        alpine)
            apk update && apk add --no-cache wget curl tar tzdata
            ;;
        opensuse-tumbleweed)
            zypper refresh && zypper -q install -y wget curl tar timezone
            ;;
        *)
            apt-get update && apt install -y -q wget curl tar tzdata
            ;;
    esac
}

# 生成随机字符串
gen_random_string() {
    local length="$1"
    local random_string=$(LC_ALL=C tr -dc 'a-zA-Z0-9' </dev/urandom | fold -w "$length" | head -n 1)
    echo "$random_string"
}

# 配置安装后设置
config_after_install() {
    echo -e "${yellow}3x-ui 安装完成，是否自定义面板设置，选择n将使用默认设置 (y/n)?${plain}"
    read -p "请输入：" config_confirm
    if [[ "${config_confirm}" == "y" || "${config_confirm}" == "Y" ]]; then
        read -p "请设置您的用户名: " config_account
        echo -e "${yellow}您的用户名将设置为:${config_account}${plain}"
        read -p "请设置您的密码: " config_password
        echo -e "${yellow}您的密码将设置为:${config_password}${plain}"
        read -p "请设置访问端口号: " config_port
        echo -e "${yellow}您的访问端口号将设置为:${config_port}${plain}"
        echo -e "${yellow}正在初始化，请稍等...${plain}"
        /usr/local/x-ui/x-ui setting -username ${config_account} -password ${config_password}
        echo -e "${yellow}用户名和密码设置完成${plain}"
        /usr/local/x-ui/x-ui setting -port ${config_port}
        echo -e "${yellow}访问端口号设置完成${plain}"
    else
        echo -e "${red}已跳过配置，使用默认设置${plain}"
    fi
}

# 安装3x-ui
install_x-ui() {
    cd /usr/local/
    
    echo -e "${green}本地化3x-ui安装开始...${plain}"
    
    # 检查本地安装包是否存在
    if [[ ! -f "$BASE_DIR/x-ui-linux-$(arch).tar.gz" ]]; then
        echo -e "${red}未找到本地安装包 x-ui-linux-$(arch).tar.gz${plain}"
        echo -e "${yellow}请确保安装包位于: $BASE_DIR/x-ui-linux-$(arch).tar.gz${plain}"
        exit 1
    fi
    
    # 停止x-ui服务并删除旧资源
    if [[ -e /usr/local/x-ui/ ]]; then
        systemctl stop x-ui
        rm /usr/local/x-ui/ -rf
    fi
    
    echo -e "${green}正在解压安装包...${plain}"
    cp "$BASE_DIR/x-ui-linux-$(arch).tar.gz" .
    tar zxvf x-ui-linux-$(arch).tar.gz
    rm x-ui-linux-$(arch).tar.gz -f
    
    cd x-ui
    chmod +x x-ui
    chmod +x x-ui.sh
    
    # 检查系统架构并重命名文件
    if [[ $(arch) == "armv5" || $(arch) == "armv6" || $(arch) == "armv7" ]]; then
        mv bin/xray-linux-$(arch) bin/xray-linux-arm
        chmod +x bin/xray-linux-arm
    fi
    
    chmod +x x-ui bin/xray-linux-$(arch)
    
    # 更新x-ui cli并设置权限  
    cp -f "$LOCAL_RESOURCES_DIR/scripts/x-ui.sh" /usr/bin/x-ui
    chmod +x /usr/bin/x-ui
    
    echo -e "${green}安装完成，正在配置服务...${plain}"
    
    config_after_install
    
    # 安装系统服务
    cp -f x-ui.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable x-ui
    systemctl start x-ui
    
    echo -e "${green}3x-ui 安装成功!${plain}"
    
    # 显示面板信息
    /usr/local/x-ui/x-ui setting -show
}

echo -e "${green}开始安装基础软件包...${plain}"
install_base

echo -e "${green}开始安装3x-ui...${plain}"
install_x-ui

echo -e "${green}安装完成！${plain}"
echo -e "${yellow}管理命令: x-ui${plain}"
echo -e "${yellow}面板服务: systemctl [start|stop|restart|status] x-ui${plain}" 
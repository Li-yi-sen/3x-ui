# 3X-UI 本地化版本使用说明

## 概述
本版本是3X-UI的完全本地化版本，所有远程依赖已移除，无需网络连接即可使用。

## 目录结构
```
local-resources/
├── scripts/              # 本地脚本文件
│   ├── local-install.sh  # 本地安装脚本
│   └── x-ui.sh          # 本地化的管理脚本
├── geo/                 # Geo数据文件
│   ├── geoip.dat
│   ├── geosite.dat
│   ├── geoip_IR.dat
│   ├── geosite_IR.dat
│   ├── geoip_VN.dat
│   └── geosite_VN.dat
├── tools/               # 工具脚本
│   ├── acme.sh          # ACME证书工具
│   └── install_warp_proxy.sh # WARP代理安装脚本
└── install/             # 安装包文件夹
```

## 使用方法

### 首次安装
1. 确保安装包 `x-ui-linux-<arch>.tar.gz` 位于3x-ui根目录
2. 运行本地安装脚本：
   ```bash
   bash local-resources/scripts/local-install.sh
   ```

### 管理命令
安装完成后，可以使用以下命令：
- `x-ui` - 进入管理菜单
- `x-ui start` - 启动服务
- `x-ui stop` - 停止服务
- `x-ui restart` - 重启服务
- `x-ui status` - 查看状态

### 本地化功能说明

#### 1. 安装和更新
- 使用本地安装包进行安装
- 更新功能使用本地脚本重新安装
- 不再依赖GitHub下载

#### 2. Geo文件更新
- 将geo文件放置在 `local-resources/geo/` 目录
- 支持的文件：
  - geoip.dat / geosite.dat（通用）
  - geoip_IR.dat / geosite_IR.dat（伊朗）
  - geoip_VN.dat / geosite_VN.dat（越南）

#### 3. SSL证书管理
- 需要将acme.sh安装脚本放置在 `local-resources/tools/acme.sh`
- 支持本地SSL证书管理功能

#### 4. 其他工具
- WARP代理：需要将安装脚本放置在 `local-resources/tools/install_warp_proxy.sh`
- Speedtest：需要手动安装或提供本地安装脚本

### 文件获取说明

#### 获取安装包
1. 从GitHub releases下载对应架构的安装包
2. 重命名为 `x-ui-linux-<arch>.tar.gz` 格式
3. 放置在3x-ui根目录

#### 获取Geo文件
从以下地址下载：
- https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/
- https://github.com/chocolate4u/Iran-v2ray-rules/releases/latest/
- https://github.com/vuong2023/vn-v2ray-rules/releases/latest/

#### 获取工具脚本
- acme.sh: https://get.acme.sh
- WARP代理脚本: https://raw.githubusercontent.com/hamid-gh98/x-ui-scripts/main/install_warp_proxy.sh

## 注意事项
1. 确保所有必要的文件都已下载到本地
2. 第一次使用前请检查目录结构是否完整
3. 定期更新geo文件以保持最新的IP和域名规则
4. 本地化版本不会自动检查更新，需要手动维护

## 故障排除
如果遇到"文件未找到"错误，请检查：
1. 文件路径是否正确
2. 文件权限是否可执行
3. 文件是否存在于指定目录

## 优势
- 完全离线运行
- 不依赖外部网络
- 避免因网络问题导致的安装失败
- 提高安装和运行的稳定性 
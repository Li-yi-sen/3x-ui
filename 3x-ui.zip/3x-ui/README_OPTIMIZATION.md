# 3X-UI 优化版本说明

## 优化概述

本版本专为解决原版3X-UI在Debian 11/12系统上的兼容性问题，并针对安全性和稳定性进行了全面优化。

## 主要优化内容

### 1. 固定端口配置

**问题**: 原版本端口配置复杂，容易出现端口冲突和配置错误
**解决方案**: 
- 管理端口固定为 8080
- 服务端口固定为 7891  
- SSH端口保持 22
- 移除端口自定义功能，避免配置错误

**修改文件**:
- `web/service/setting.go`: 修改默认端口配置
- `x-ui.sh`: 修改端口设置函数
- `install.sh`: 添加固定端口配置逻辑

### 2. Debian 11/12 兼容性优化

**问题**: 原版本在Debian 11/12上存在包依赖问题
**解决方案**:
- 添加Debian版本检测
- 优化包管理器配置
- 修复glibc版本检查
- 添加必要的系统包

**修改文件**:
- `install.sh`: 添加Debian版本检测和优化包安装

### 3. 防火墙配置优化

**问题**: 原版防火墙配置不够完善，端口开启不立即生效
**解决方案**:
- 自动安装和配置UFW防火墙
- 强制重置防火墙规则
- 添加端口注释说明
- 确保配置立即生效

**修改文件**:
- `install.sh`: 添加setup_firewall函数
- `x-ui.sh`: 优化防火墙管理函数

### 4. 本地化安装

**问题**: 原版本依赖GitHub API和网络下载，网络问题容易导致安装失败
**解决方案**:
- 支持完全本地安装，用户下载完整项目后可离线安装
- 自动检测本地安装模式和远程安装模式
- 移除GitHub API依赖，改为直接下载或本地安装
- 提供多种安装方式供用户选择

**安装流程对比**:

```bash
# 优化前：必须联网下载
bash <(curl -Ls https://raw.githubusercontent.com/xxx/install.sh)

# 优化后：推荐程序包安装
wget https://github.com/Li-yi-sen/3x-ui/raw/main/3x-ui.zip
unzip 3x-ui.zip
cd 3x-ui && ./install.sh
```

**程序包说明**:
- 程序包文件: `3x-ui.zip`
- 直接下载地址: https://github.com/Li-yi-sen/3x-ui/raw/main/3x-ui.zip
- 解压后即可获得完整的可执行程序和配置文件
- 无需下载整个仓库源代码

**修改文件**:
- `install.sh`: 添加本地安装检测和双模式支持
- `README.md`: 更新安装说明，推荐本地安装

### 5. 移除升级功能

**问题**: 升级功能可能导致版本冲突和配置丢失
**解决方案**:
- 完全移除update相关函数
- 移除legacy_version函数  
- 移除update_menu函数
- 简化管理菜单

**修改文件**:
- `x-ui.sh`: 删除所有升级相关函数
- 更新管理菜单布局

## 配置文件对比

### 端口配置 (setting.go)

```go
// 优化前
"webPort": "2053",
"subPort": "2096",

// 优化后  
"webPort": "8080",
"subPort": "7891",
```

### 防火墙配置 (install.sh)

```bash
# 优化前
ufw allow 2053/tcp
ufw allow 2096/tcp

# 优化后
ufw allow 22/tcp comment 'SSH'
ufw allow 8080/tcp comment 'X-UI Management Panel'
ufw allow 7891/tcp comment 'X-UI Internal Service'
ufw reload
systemctl reload ufw
```

## 安装流程对比

### 优化前安装流程
1. 检查系统环境
2. 从GitHub API获取最新版本
3. 下载对应版本文件
4. 随机生成端口配置
5. 基础防火墙配置

### 优化后安装流程
1. 检查系统环境 + Debian版本检测
2. 安装优化后的系统包
3. 从指定仓库下载固定版本
4. 使用固定端口配置
5. 完整防火墙配置 + 立即生效
6. 本地管理脚本安装

## 管理菜单变化

### 优化前菜单项
- 25个选项，包含多个升级功能
- 端口可自定义配置
- 复杂的更新选项

### 优化后菜单项  
- 21个选项，移除升级功能
- 端口固定显示
- 简化的管理选项

## 兼容性说明

### 支持系统
- ✅ Debian 11 (Bullseye)
- ✅ Debian 12 (Bookworm)
- ✅ Ubuntu 20.04+
- ⚠️ CentOS/RHEL (基础支持)

### 不兼容功能
- ❌ 在线升级
- ❌ 版本回退
- ❌ 自定义端口
- ❌ 动态防火墙配置

## 部署建议

1. **新安装**: 直接使用优化版本
2. **从原版迁移**: 需要重新安装，无法直接升级
3. **生产环境**: 建议先在测试环境验证
4. **备份**: 迁移前务必备份原有配置

## 维护说明

由于移除了升级功能，版本维护采用以下方式：
- 重大更新通过重新安装实现
- 配置文件可导出/导入保持设置
- 定期发布稳定版本压缩包
- 提供手动升级指导文档

## 技术支持

如遇到问题，请提供以下信息：
1. 系统版本: `cat /etc/os-release`
2. 服务状态: `systemctl status x-ui`
3. 防火墙状态: `ufw status`
4. 端口监听: `netstat -tlnp | grep -E '(8080|7891)'`
5. 错误日志: `journalctl -u x-ui --no-pager` 
#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
blue='\033[0;34m'
yellow='\033[0;33m'
plain='\033[0m'

cur_dir=$(pwd)

# check root
[[ $EUID -ne 0 ]] && echo -e "${red}Fatal error: ${plain} Please run this script with root privilege \n " && exit 1

# Check if running from project directory (local install)
is_local_install=false
if [[ -f "${cur_dir}/x-ui.sh" && -f "${cur_dir}/x-ui.service" && -d "${cur_dir}/web" ]]; then
    is_local_install=true
    echo -e "${green}检测到本地安装模式 - 程序包${plain}"
elif [[ -f "${cur_dir}/3x-ui.zip" ]]; then
    echo -e "${yellow}检测到程序包文件，正在解压...${plain}"
    unzip -q "${cur_dir}/3x-ui.zip"
    if [[ -d "${cur_dir}/3x-ui" ]]; then
        cd "${cur_dir}/3x-ui"
        cur_dir="${cur_dir}/3x-ui"
        is_local_install=true
        echo -e "${green}程序包解压完成，使用本地安装模式${plain}"
    else
        echo -e "${red}程序包解压失败${plain}"
        exit 1
    fi
else
    echo -e "${yellow}网络安装模式${plain}"
fi

# Check OS and set release variable
if [[ -f /etc/os-release ]]; then
    source /etc/os-release
    release=$ID
elif [[ -f /usr/lib/os-release ]]; then
    source /usr/lib/os-release
    release=$ID
else
    echo "Failed to check the system OS, please contact the author!" >&2
    exit 1
fi
echo "The OS release is: $release"

# Get version ID for Debian
os_version=""
if [[ "${release}" == "debian" ]]; then
    os_version=$(grep "^VERSION_ID" /etc/os-release | cut -d '=' -f2 | tr -d '"')
    echo "Debian version: $os_version"
fi

arch() {
    case "$(uname -m)" in
    x86_64 | x64 | amd64) echo 'amd64' ;;
    i*86 | x86) echo '386' ;;
    armv8* | armv8 | arm64 | aarch64) echo 'arm64' ;;
    armv7* | armv7 | arm) echo 'armv7' ;;
    armv6* | armv6) echo 'armv6' ;;
    armv5* | armv5) echo 'armv5' ;;
    s390x) echo 's390x' ;;
    *) echo -e "${green}Unsupported CPU architecture! ${plain}" && rm -f install.sh && exit 1 ;;
    esac
}

echo "Arch: $(arch)"

check_glibc_version() {
    glibc_version=$(ldd --version | head -n1 | awk '{print $NF}')
    
    required_version="2.32"
    if [[ "$(printf '%s\n' "$required_version" "$glibc_version" | sort -V | head -n1)" != "$required_version" ]]; then
        echo -e "${red}GLIBC version $glibc_version is too old! Required: 2.32 or higher${plain}"
        echo "Please upgrade to a newer version of your operating system to get a higher GLIBC version."
        exit 1
    fi
    echo "GLIBC version: $glibc_version (meets requirement of 2.32+)"
}
check_glibc_version

install_base() {
    case "${release}" in
    ubuntu | debian | armbian)
        # Fix for Debian 11/12 compatibility
        apt-get update && apt-get install -y -q wget curl tar tzdata ca-certificates
        # Install additional packages for Debian 11/12
        if [[ "${release}" == "debian" ]] && [[ "${os_version}" -ge "11" ]]; then
            apt-get install -y -q software-properties-common
        fi
        ;;
    centos | rhel | almalinux | rocky | ol)
        yum -y update && yum install -y -q wget curl tar tzdata ca-certificates
        ;;
    fedora | amzn | virtuozzo)
        dnf -y update && dnf install -y -q wget curl tar tzdata ca-certificates
        ;;
    arch | manjaro | parch)
        pacman -Syu && pacman -Syu --noconfirm wget curl tar tzdata ca-certificates
        ;;
    opensuse-tumbleweed)
        zypper refresh && zypper -q install -y wget curl tar timezone ca-certificates
        ;;
    *)
        apt-get update && apt install -y -q wget curl tar tzdata ca-certificates
        ;;
    esac
}

# Setup firewall with fixed ports
setup_firewall() {
    echo -e "${green}Setting up firewall with fixed ports...${plain}"
    
    case "${release}" in
    ubuntu | debian | armbian)
        # Install UFW if not present
        if ! command -v ufw &>/dev/null; then
            apt-get update && apt-get install -y ufw
        fi
        
        # Configure firewall rules
        ufw --force reset
        ufw --force enable
        
        # Allow essential ports
        ufw allow 22/tcp comment 'SSH'
        ufw allow 8080/tcp comment 'X-UI Management Panel'
        ufw allow 7891/tcp comment 'X-UI Internal Service'
        
        # Reload firewall to ensure rules take effect immediately
        ufw reload
        systemctl reload ufw 2>/dev/null || true
        
        echo -e "${green}Firewall configured successfully!${plain}"
        echo -e "${yellow}Open ports: 22 (SSH), 8080 (Management), 7891 (Service)${plain}"
        ;;
    centos | rhel | almalinux | rocky | ol)
        # Configure firewalld
        if command -v firewall-cmd &>/dev/null; then
            systemctl start firewalld
            systemctl enable firewalld
            
            firewall-cmd --permanent --add-port=22/tcp
            firewall-cmd --permanent --add-port=8080/tcp
            firewall-cmd --permanent --add-port=7891/tcp
            
            firewall-cmd --reload
            echo -e "${green}Firewall configured successfully!${plain}"
        fi
        ;;
    esac
}

gen_random_string() {
    local length="$1"
    local random_string=$(LC_ALL=C tr -dc 'a-zA-Z0-9' </dev/urandom | fold -w "$length" | head -n 1)
    echo "$random_string"
}

config_after_install() {
    # Set fixed configuration
    local config_webBasePath=$(gen_random_string 18)
    local config_username=$(gen_random_string 10)
    local config_password=$(gen_random_string 10)
    local config_port=8080  # Fixed port

    /usr/local/x-ui/x-ui setting -username "${config_username}" -password "${config_password}" -port "${config_port}" -webBasePath "${config_webBasePath}"
    
    # Get server IP
    local server_ip=$(curl -s --max-time 3 https://api.ipify.org 2>/dev/null || curl -s --max-time 3 https://4.ident.me 2>/dev/null || echo "YOUR_SERVER_IP")
    
    echo -e "###############################################"
    echo -e "${green}3X-UI Installed Successfully!${plain}"
    echo -e "${green}Username: ${config_username}${plain}"
    echo -e "${green}Password: ${config_password}${plain}"
    echo -e "${green}Management Port: ${config_port}${plain}"
    echo -e "${green}Service Port: 7891${plain}"
    echo -e "${green}SSH Port: 22${plain}"
    echo -e "${green}WebBasePath: ${config_webBasePath}${plain}"
    echo -e "${green}Access URL: http://${server_ip}:${config_port}/${config_webBasePath}${plain}"
    echo -e "###############################################"

    /usr/local/x-ui/x-ui migrate
}

install_x-ui() {
    if [[ "$is_local_install" == "true" ]]; then
        echo -e "${green}使用本地文件安装...${plain}"
        install_from_local
    else
        echo -e "${yellow}从远程仓库下载安装...${plain}"
        install_from_remote
    fi
}

install_from_local() {
    echo -e "${green}本地安装模式启动...${plain}"
    
    # Stop existing service
    if [[ -e /usr/local/x-ui/ ]]; then
        systemctl stop x-ui 2>/dev/null || true
        rm /usr/local/x-ui/ -rf
    fi

    # Create target directory
    mkdir -p /usr/local/x-ui
    
    # Copy all files to target directory
    echo -e "${yellow}复制文件到 /usr/local/x-ui/ ...${plain}"
    cp -r "${cur_dir}"/* /usr/local/x-ui/
    
    cd /usr/local/x-ui
    chmod +x x-ui
    chmod +x x-ui.sh

    # Check architecture and set permissions
    if [[ $(arch) == "armv5" || $(arch) == "armv6" || $(arch) == "armv7" ]]; then
        if [[ -f "bin/xray-linux-$(arch)" ]]; then
            mv bin/xray-linux-$(arch) bin/xray-linux-arm
            chmod +x bin/xray-linux-arm
        fi
    fi
    
    if [[ -f "bin/xray-linux-$(arch)" ]]; then
        chmod +x bin/xray-linux-$(arch)
    fi

    # Set up configuration
    config_after_install

    # Install management script locally
    cp -f x-ui.sh /usr/bin/x-ui
    chmod +x /usr/bin/x-ui

    # Setup systemd service
    cp -f x-ui.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable x-ui
    systemctl start x-ui
    
    # Setup firewall
    setup_firewall
    
    echo -e "${green}本地安装完成！${plain}"
}

install_from_remote() {
    cd /usr/local/

    # Download from your repository instead of GitHub API
    local download_url="https://github.com/Li-yi-sen/3x-ui/releases/download/v1.0.0/x-ui-linux-$(arch).tar.gz"
    
    echo -e "Beginning to install x-ui from remote repository..."
    wget -N -O /usr/local/x-ui-linux-$(arch).tar.gz "${download_url}"
    
    if [[ $? -ne 0 ]]; then
        echo -e "${red}Download x-ui failed, please check if the file exists in your repository ${plain}"
        echo -e "${yellow}建议使用本地安装方式：${plain}"
        echo -e "1. 下载程序包: wget https://github.com/Li-yi-sen/3x-ui/raw/main/3x-ui.zip"
        echo -e "2. 解压: unzip 3x-ui.zip"  
        echo -e "3. 安装: cd 3x-ui && ./install.sh"
        exit 1
    fi

    # Stop x-ui service and remove old resources
    if [[ -e /usr/local/x-ui/ ]]; then
        systemctl stop x-ui 2>/dev/null || true
        rm /usr/local/x-ui/ -rf
    fi

    # Extract resources and set permissions
    tar zxvf x-ui-linux-$(arch).tar.gz
    rm x-ui-linux-$(arch).tar.gz -f
    
    cd x-ui
    chmod +x x-ui
    chmod +x x-ui.sh

    # Check the system's architecture and rename the file accordingly
    if [[ $(arch) == "armv5" || $(arch) == "armv6" || $(arch) == "armv7" ]]; then
        mv bin/xray-linux-$(arch) bin/xray-linux-arm
        chmod +x bin/xray-linux-arm
    fi
    chmod +x x-ui bin/xray-linux-$(arch)

    # Set up configuration after installation
    config_after_install

    # Install management script locally
    cp -f x-ui.sh /usr/bin/x-ui
    chmod +x /usr/bin/x-ui

    # Setup systemd service
    cp -f x-ui.service /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable x-ui
    systemctl start x-ui
    
    # Setup firewall
    setup_firewall
    
    echo -e "${green}远程安装完成！${plain}"
}

echo -e "${green}Running...${plain}"
install_base
install_x-ui $1

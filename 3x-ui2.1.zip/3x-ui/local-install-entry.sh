#!/bin/bash

# 3X-UI 本地化版本入口脚本
# 该脚本提供了完全本地化的3X-UI安装和管理功能

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
plain='\033[0m'

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOCAL_RESOURCES_DIR="$SCRIPT_DIR/local-resources"

# 显示欢迎信息
show_welcome() {
    clear
    echo -e "${blue}================================================${plain}"
    echo -e "${green}          3X-UI 本地化版本管理脚本${plain}"
    echo -e "${yellow}            完全离线 | 无需网络${plain}"
    echo -e "${blue}================================================${plain}"
    echo ""
}

# 检查环境
check_environment() {
    # 检查是否为root用户
    if [[ $EUID -ne 0 ]]; then
        echo -e "${red}错误: 请使用 root 权限运行此脚本${plain}"
        exit 1
    fi

    # 检查本地资源目录
    if [[ ! -d "$LOCAL_RESOURCES_DIR" ]]; then
        echo -e "${red}错误: 本地资源目录不存在: $LOCAL_RESOURCES_DIR${plain}"
        echo -e "${yellow}请确保 local-resources 目录存在且包含必要文件${plain}"
        exit 1
    fi

    # 检查关键脚本文件
    if [[ ! -f "$LOCAL_RESOURCES_DIR/scripts/local-install.sh" ]]; then
        echo -e "${red}错误: 本地安装脚本不存在${plain}"
        echo -e "${yellow}请检查: $LOCAL_RESOURCES_DIR/scripts/local-install.sh${plain}"
        exit 1
    fi

    if [[ ! -f "$LOCAL_RESOURCES_DIR/scripts/x-ui.sh" ]]; then
        echo -e "${red}错误: 本地管理脚本不存在${plain}"
        echo -e "${yellow}请检查: $LOCAL_RESOURCES_DIR/scripts/x-ui.sh${plain}"
        exit 1
    fi
}

# 检查安装状态
check_install_status() {
    if command -v x-ui &>/dev/null && [[ -f /etc/systemd/system/x-ui.service ]]; then
        return 0  # 已安装
    else
        return 1  # 未安装
    fi
}

# 显示主菜单
show_main_menu() {
    echo -e "${green}请选择操作：${plain}"
    echo ""
    echo -e "${green}1.${plain} 全新安装 3X-UI"
    echo -e "${green}2.${plain} 进入管理菜单 (已安装)"
    echo -e "${green}3.${plain} 检查本地资源状态"
    echo -e "${green}4.${plain} 查看使用说明"
    echo -e "${green}0.${plain} 退出"
    echo ""
}

# 检查本地资源
check_local_resources() {
    echo -e "${yellow}检查本地资源状态...${plain}"
    echo ""
    
    # 检查安装包
    echo -e "${blue}1. 安装包检查:${plain}"
    local arch_type=""
    case "$(uname -m)" in
        x86_64 | x64 | amd64 ) arch_type='amd64' ;;
        i*86 | x86 ) arch_type='386' ;;
        armv8* | armv8 | arm64 | aarch64 ) arch_type='arm64' ;;
        armv7* | armv7 | arm ) arch_type='armv7' ;;
        armv6* | armv6 ) arch_type='armv6' ;;
        armv5* | armv5 ) arch_type='armv5' ;;
        s390x) arch_type='s390x' ;;
        *) arch_type='unknown' ;;
    esac
    
    local install_pkg="$SCRIPT_DIR/x-ui-linux-${arch_type}.tar.gz"
    if [[ -f "$install_pkg" ]]; then
        echo -e "   ${green}✓${plain} 安装包存在: x-ui-linux-${arch_type}.tar.gz"
    else
        echo -e "   ${red}✗${plain} 安装包缺失: x-ui-linux-${arch_type}.tar.gz"
    fi
    
    # 检查脚本文件
    echo -e "${blue}2. 脚本文件检查:${plain}"
    local scripts=("local-install.sh" "x-ui.sh")
    for script in "${scripts[@]}"; do
        if [[ -f "$LOCAL_RESOURCES_DIR/scripts/$script" ]]; then
            echo -e "   ${green}✓${plain} $script"
        else
            echo -e "   ${red}✗${plain} $script"
        fi
    done
    
    # 检查geo文件
    echo -e "${blue}3. Geo文件检查:${plain}"
    local geo_files=("geoip.dat" "geosite.dat" "geoip_IR.dat" "geosite_IR.dat" "geoip_VN.dat" "geosite_VN.dat")
    for geo_file in "${geo_files[@]}"; do
        if [[ -f "$LOCAL_RESOURCES_DIR/geo/$geo_file" ]]; then
            echo -e "   ${green}✓${plain} $geo_file"
        else
            echo -e "   ${yellow}○${plain} $geo_file (可选)"
        fi
    done
    
    # 检查工具文件
    echo -e "${blue}4. 工具文件检查:${plain}"
    local tools=("acme.sh" "install_warp_proxy.sh")
    for tool in "${tools[@]}"; do
        if [[ -f "$LOCAL_RESOURCES_DIR/tools/$tool" ]]; then
            echo -e "   ${green}✓${plain} $tool"
        else
            echo -e "   ${yellow}○${plain} $tool (可选)"
        fi
    done
    
    echo ""
}

# 执行安装
run_install() {
    echo -e "${green}开始安装 3X-UI 本地化版本...${plain}"
    echo ""
    
    # 设置脚本权限
    chmod +x "$LOCAL_RESOURCES_DIR/scripts/local-install.sh"
    
    # 执行安装
    bash "$LOCAL_RESOURCES_DIR/scripts/local-install.sh"
    
    if [[ $? -eq 0 ]]; then
        echo ""
        echo -e "${green}安装完成！${plain}"
        echo -e "${yellow}现在可以使用 'x-ui' 命令进行管理${plain}"
    else
        echo -e "${red}安装失败，请检查错误信息${plain}"
    fi
}

# 进入管理菜单
enter_management() {
    if check_install_status; then
        x-ui
    else
        echo -e "${red}3X-UI 未安装，请先执行安装${plain}"
        echo ""
    fi
}

# 显示使用说明
show_usage() {
    if [[ -f "$LOCAL_RESOURCES_DIR/README.md" ]]; then
        echo -e "${green}正在显示使用说明...${plain}"
        echo ""
        cat "$LOCAL_RESOURCES_DIR/README.md"
    else
        echo -e "${yellow}使用说明文件不存在${plain}"
        echo -e "${green}基本使用方法：${plain}"
        echo "1. 确保本地资源完整"
        echo "2. 运行安装选项"
        echo "3. 使用 x-ui 命令管理"
    fi
    echo ""
    echo -e "${yellow}按任意键返回主菜单...${plain}"
    read -n 1
}

# 主程序
main() {
    show_welcome
    check_environment
    
    while true; do
        show_main_menu
        read -p "请输入选择 [0-4]: " choice
        
        case $choice in
            1)
                echo ""
                run_install
                echo ""
                echo -e "${yellow}按任意键继续...${plain}"
                read -n 1
                clear
                show_welcome
                ;;
            2)
                echo ""
                enter_management
                clear
                show_welcome
                ;;
            3)
                echo ""
                check_local_resources
                echo -e "${yellow}按任意键继续...${plain}"
                read -n 1
                clear
                show_welcome
                ;;
            4)
                clear
                show_usage
                clear
                show_welcome
                ;;
            0)
                echo ""
                echo -e "${green}感谢使用 3X-UI 本地化版本！${plain}"
                exit 0
                ;;
            *)
                echo ""
                echo -e "${red}无效选择，请重新输入${plain}"
                sleep 1
                clear
                show_welcome
                ;;
        esac
    done
}

# 运行主程序
main 
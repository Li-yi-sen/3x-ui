#!/bin/bash

# 3X-UI 端口管理功能安装脚本
# 适用于手动安装到现有的 3x-ui 系统

echo "=========================================="
echo "3X-UI 端口管理功能安装脚本"
echo "=========================================="

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then 
    echo "请使用root用户运行此脚本"
    exit 1
fi

# 检查3x-ui是否已安装
if ! systemctl list-units --full -all | grep -Fq "x-ui.service"; then
    echo "错误：未检测到 x-ui 服务，请先安装 3x-ui"
    exit 1
fi

echo "✅ 检测到 3x-ui 服务"

# 停止x-ui服务
echo "🔄 停止 x-ui 服务..."
systemctl stop x-ui

# 备份原始文件
BACKUP_DIR="/root/x-ui-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

echo "📁 创建备份目录: $BACKUP_DIR"

# 查找x-ui安装目录
X_UI_DIR=""
for dir in "/usr/local/x-ui" "/opt/x-ui" "/root/x-ui"; do
    if [ -f "$dir/x-ui" ]; then
        X_UI_DIR="$dir"
        break
    fi
done

if [ -z "$X_UI_DIR" ]; then
    echo "❌ 未找到 x-ui 安装目录"
    exit 1
fi

echo "📍 找到 x-ui 目录: $X_UI_DIR"

# 备份关键文件
echo "💾 备份原始文件..."
cp -r "$X_UI_DIR" "$BACKUP_DIR/"
cp /usr/bin/x-ui "$BACKUP_DIR/" 2>/dev/null || true

# 复制新的防火墙脚本
echo "📝 更新防火墙管理脚本..."
if [ -f "./x-ui.sh" ]; then
    cp ./x-ui.sh /usr/bin/x-ui
    chmod +x /usr/bin/x-ui
    echo "✅ 防火墙脚本已更新"
else
    echo "❌ 未找到新的 x-ui.sh 脚本"
fi

# 检查Go环境
if ! command -v go &> /dev/null; then
    echo "📦 安装Go环境..."
    # 安装Go (版本1.19+)
    cd /tmp
    wget -q https://go.dev/dl/go1.20.linux-amd64.tar.gz
    tar -C /usr/local -xzf go1.20.linux-amd64.tar.gz
    export PATH=$PATH:/usr/local/go/bin
    echo 'export PATH=$PATH:/usr/local/go/bin' >> /root/.bashrc
    echo "✅ Go环境已安装"
fi

# 编译新版本
echo "🔨 编译包含端口管理功能的新版本..."
cd "$(dirname "$0")"

# 设置Go环境变量
export CGO_ENABLED=1
export CGO_CFLAGS="-D_LARGEFILE64_SOURCE"

# 编译
if go build -ldflags "-w -s" -o "$X_UI_DIR/x-ui-new" main.go; then
    echo "✅ 编译成功"
    
    # 备份旧版本并替换
    mv "$X_UI_DIR/x-ui" "$X_UI_DIR/x-ui-old"
    mv "$X_UI_DIR/x-ui-new" "$X_UI_DIR/x-ui"
    chmod +x "$X_UI_DIR/x-ui"
    
    echo "✅ 程序文件已替换"
else
    echo "❌ 编译失败"
    exit 1
fi

# 复制web文件
echo "🌐 更新Web文件..."
if [ -d "$X_UI_DIR/web" ]; then
    cp -r ./web/* "$X_UI_DIR/web/"
    echo "✅ Web文件已更新"
fi

# 启动服务
echo "🚀 启动 x-ui 服务..."
systemctl start x-ui
systemctl status x-ui --no-pager -l

echo ""
echo "=========================================="
echo "✅ 端口管理功能安装完成！"
echo "=========================================="
echo "📌 备份位置: $BACKUP_DIR"
echo "🌐 访问地址: http://your-server-ip:2053"
echo "🔧 新功能:"
echo "   - 侧栏菜单新增'端口管理'选项"
echo "   - 入站规则自动激活端口"
echo "   - 批量端口管理功能"
echo "   - 命令行: x-ui -> 21 -> 5"
echo ""
echo "如果出现问题，可以恢复备份:"
echo "systemctl stop x-ui"
echo "cp $BACKUP_DIR/x-ui-backup/x-ui $X_UI_DIR/"
echo "systemctl start x-ui"
echo "==========================================" 
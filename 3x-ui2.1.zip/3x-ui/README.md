# 3X-UI

> 🛡️ 基于Xray Core的高性能代理面板 - 本地化优化版本

一个功能强大的代理管理面板，完全本地化部署，支持多种协议和完整的Web管理界面。

## 🚀 一键部署

**最简单的方式，一个命令搞定一切：**

```bash
wget -O - https://github.com/Li-yi-sen/3x-ui/raw/main/一键部署.sh | sudo bash
```

## ✨ 主要特性

- 🌐 **Web管理界面**: 现代化的响应式Web界面
- 🔧 **多协议支持**: VMess、VLESS、Trojan、Shadowsocks等
- 📊 **流量统计**: 实时流量监控和用户管理
- 🛡️ **独立防火墙**: 5555端口独立防火墙管理界面
- 🌍 **双语支持**: 中文和英文界面
- 📦 **完全本地化**: 无需网络依赖，离线部署
- 🐳 **容器化支持**: Docker和Docker Compose部署

## 🎮 快速开始

### 📋 系统要求
- Linux系统 (Ubuntu 20+, Debian 11+, CentOS 8+等)
- Root权限
- 至少512MB内存

### ⚡ 部署方式

#### 方式1: 一键部署 (推荐)
```bash
# 直接执行一键部署
wget -O - https://github.com/Li-yi-sen/3x-ui/raw/main/一键部署.sh | sudo bash
```

#### 方式2: 手动部署
```bash
# 下载项目
wget https://github.com/Li-yi-sen/3x-ui/archive/refs/heads/main.zip
unzip main.zip && cd 3x-ui-main

# 运行安装
sudo bash local-install-entry.sh
```

#### 方式3: Docker部署
```bash
# 克隆项目
git clone https://github.com/Li-yi-sen/3x-ui.git
cd 3x-ui

# 启动容器
docker-compose up -d
```

### 🌐 访问面板

部署完成后访问：
- **主面板**: `http://您的服务器IP:2053`
- **防火墙管理**: `http://您的服务器IP:5555`
- **默认账号**: 用户名 `admin` / 密码 `admin`

### 🎮 管理命令
```bash
x-ui                    # 管理菜单
x-ui start             # 启动服务
x-ui stop              # 停止服务
x-ui restart           # 重启服务
x-ui status            # 查看状态
```

## 📚 详细文档

- **[📖 完整使用说明](README-完整说明.md)** - 详细的功能介绍和使用指南
- **[📦 部署说明](部署说明.md)** - 各种部署方式的详细步骤
- **[🔄 版本更新说明](版本更新说明.md)** - 最新版本更新内容

## 🏠 本地化特性

- ✅ **完全离线**: 无需依赖外部网络资源
- ✅ **本地安装包**: 使用本地tar.gz安装包
- ✅ **本地脚本**: 所有管理脚本本地化
- ✅ **独立防火墙**: 专用的防火墙管理界面
- ✅ **双语精简**: 专注中英文双语支持

## 🤝 贡献

欢迎提交Issue和Pull Request来改进项目！

## 📄 许可证

本项目基于 [GPL v3 License](LICENSE) 开源。

---

**🎉 选择3X-UI，享受稳定可靠的本地化代理管理体验！**

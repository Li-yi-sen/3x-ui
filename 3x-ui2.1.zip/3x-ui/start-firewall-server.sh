#!/bin/bash

# 防火墙管理服务器启动脚本
# 运行在端口 5555

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
plain='\033[0m'

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIREWALL_SERVER_DIR="$SCRIPT_DIR/web/firewall-server"
BINARY_NAME="firewall-server"

# 检查是否为root用户
if [[ $EUID -ne 0 ]]; then
    echo -e "${red}错误: 防火墙管理需要 root 权限${plain}"
    exit 1
fi

# 检查Go是否安装
if ! command -v go &> /dev/null; then
    echo -e "${red}错误: 未找到Go编译器${plain}"
    echo -e "${yellow}请先安装Go: https://golang.org/dl/${plain}"
    exit 1
fi

# 编译防火墙服务器
echo -e "${blue}📦 正在编译防火墙服务器...${plain}"
cd "$FIREWALL_SERVER_DIR"

if ! go build -o "$BINARY_NAME" main.go; then
    echo -e "${red}❌ 编译失败${plain}"
    exit 1
fi

echo -e "${green}✅ 编译成功${plain}"

# 检查端口是否被占用
if netstat -tuln | grep -q ":5555 "; then
    echo -e "${yellow}⚠️  端口 5555 已被占用${plain}"
    echo -e "${yellow}正在查找占用进程...${plain}"
    
    PID=$(lsof -t -i:5555 2>/dev/null)
    if [[ -n "$PID" ]]; then
        echo -e "${yellow}发现进程 PID: $PID${plain}"
        read -p "是否终止该进程? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            kill -9 $PID
            echo -e "${green}✅ 进程已终止${plain}"
            sleep 2
        else
            echo -e "${red}❌ 取消启动${plain}"
            exit 1
        fi
    fi
fi

# 启动服务器
echo -e "${blue}🚀 正在启动防火墙管理服务器...${plain}"
echo -e "${green}📡 访问地址: http://$(hostname -I | awk '{print $1}'):5555${plain}"
echo -e "${green}🔥 本地访问: http://localhost:5555${plain}"
echo -e "${yellow}💡 提示: 按 Ctrl+C 停止服务${plain}"
echo ""

# 后台运行选项
read -p "是否在后台运行? (y/N): " -n 1 -r
echo

if [[ $REPLY =~ ^[Yy]$ ]]; then
    # 后台运行
    nohup ./"$BINARY_NAME" > firewall-server.log 2>&1 &
    PID=$!
    echo $PID > firewall-server.pid
    
    echo -e "${green}✅ 防火墙服务器已在后台启动${plain}"
    echo -e "${blue}📋 进程ID: $PID${plain}"
    echo -e "${blue}📄 日志文件: $FIREWALL_SERVER_DIR/firewall-server.log${plain}"
    echo -e "${yellow}💡 停止服务: bash $SCRIPT_DIR/stop-firewall-server.sh${plain}"
else
    # 前台运行
    ./"$BINARY_NAME"
fi 
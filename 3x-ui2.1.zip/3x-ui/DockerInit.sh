#!/bin/sh

# 获取最新的Xray版本
XRAY_VERSION="v25.12.31"  # 更新到最新版本

case $1 in
    amd64)
        ARCH="64"
        FNAME="amd64"
        ;;
    i386)
        ARCH="32"
        FNAME="i386"
        ;;
    armv8 | arm64 | aarch64)
        ARCH="arm64-v8a"
        FNAME="arm64"
        ;;
    armv7 | arm | arm32)
        ARCH="arm32-v7a"
        FNAME="arm32"
        ;;
    armv6)
        ARCH="arm32-v6"
        FNAME="armv6"
        ;;
    *)
        ARCH="64"
        FNAME="amd64"
        ;;
esac

echo "正在为 ${FNAME} 架构下载 Xray ${XRAY_VERSION}..."

mkdir -p build/bin
cd build/bin

# 下载Xray核心
echo "下载 Xray 核心..."
wget -q "https://github.com/XTLS/Xray-core/releases/download/${XRAY_VERSION}/Xray-linux-${ARCH}.zip" || {
    echo "下载 Xray 失败，尝试备用链接..."
    wget -q "https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-${ARCH}.zip"
}

if [ -f "Xray-linux-${ARCH}.zip" ]; then
    unzip -q "Xray-linux-${ARCH}.zip"
    rm -f "Xray-linux-${ARCH}.zip" geoip.dat geosite.dat
    mv xray "xray-linux-${FNAME}"
    chmod +x "xray-linux-${FNAME}"
    echo "Xray 核心下载完成"
else
    echo "错误: Xray 下载失败"
    exit 1
fi

# 下载Geo文件
echo "下载 Geo 数据文件..."

# 通用Geo文件
wget -q -O geoip.dat https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat || 
wget -q -O geoip.dat https://cdn.jsdelivr.net/gh/Loyalsoldier/v2ray-rules-dat@release/geoip.dat

wget -q -O geosite.dat https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat ||
wget -q -O geosite.dat https://cdn.jsdelivr.net/gh/Loyalsoldier/v2ray-rules-dat@release/geosite.dat

# 伊朗Geo文件
echo "下载伊朗规则文件..."
wget -q -O geoip_IR.dat https://github.com/chocolate4u/Iran-v2ray-rules/releases/latest/download/geoip.dat ||
wget -q -O geoip_IR.dat https://cdn.jsdelivr.net/gh/chocolate4u/Iran-v2ray-rules@release/geoip.dat

wget -q -O geosite_IR.dat https://github.com/chocolate4u/Iran-v2ray-rules/releases/latest/download/geosite.dat ||
wget -q -O geosite_IR.dat https://cdn.jsdelivr.net/gh/chocolate4u/Iran-v2ray-rules@release/geosite.dat

# 俄罗斯Geo文件
echo "下载俄罗斯规则文件..."
wget -q -O geoip_RU.dat https://github.com/runetfreedom/russia-v2ray-rules-dat/releases/latest/download/geoip.dat ||
echo "俄罗斯 geoip 文件下载失败，跳过..."

wget -q -O geosite_RU.dat https://github.com/runetfreedom/russia-v2ray-rules-dat/releases/latest/download/geosite.dat ||
echo "俄罗斯 geosite 文件下载失败，跳过..."

# 越南Geo文件
echo "下载越南规则文件..."
wget -q -O geoip_VN.dat https://github.com/vuong2023/vn-v2ray-rules/releases/latest/download/geoip.dat ||
echo "越南 geoip 文件下载失败，跳过..."

wget -q -O geosite_VN.dat https://github.com/vuong2023/vn-v2ray-rules/releases/latest/download/geosite.dat ||
echo "越南 geosite 文件下载失败，跳过..."

echo "Geo 文件下载完成"

# 验证必要文件
if [ ! -f "xray-linux-${FNAME}" ]; then
    echo "错误: Xray 可执行文件不存在"
    exit 1
fi

if [ ! -f "geoip.dat" ] || [ ! -f "geosite.dat" ]; then
    echo "错误: 必要的 Geo 文件缺失"
    exit 1
fi

echo "所有文件准备完成，架构: ${FNAME}"
ls -la

cd ../../
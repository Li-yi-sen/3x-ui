#!/bin/sh

# Docker入口脚本 - 3X-UI 最新版本
echo "🚀 启动 3X-UI 容器..."

# 设置时区
echo "⏰ 设置时区为: ${TZ:-Asia/Shanghai}"
ln -sf /usr/share/zoneinfo/${TZ:-Asia/Shanghai} /etc/localtime

# 创建必要的目录
mkdir -p /etc/x-ui /var/log/x-ui /var/log/fail2ban

# 检查数据库目录权限
if [ -d "/etc/x-ui" ]; then
    chmod 755 /etc/x-ui
    echo "📁 数据库目录权限已设置"
fi

# 初始化fail2ban配置
if [ "$XUI_ENABLE_FAIL2BAN" = "true" ]; then
    echo "🛡️ 启用 fail2ban 保护..."
    
    # 确保fail2ban目录存在
    mkdir -p /var/run/fail2ban /var/lib/fail2ban
    
    # 启动fail2ban
    if fail2ban-client -x start 2>/dev/null; then
        echo "✅ fail2ban 启动成功"
    else
        echo "⚠️ fail2ban 启动失败，继续启动主程序"
    fi
else
    echo "🔕 fail2ban 已禁用"
fi

# 检查Xray核心文件
if [ -f "/app/bin/xray-linux-amd64" ] || [ -f "/app/bin/xray-linux-arm64" ]; then
    echo "✅ Xray 核心文件检查通过"
else
    echo "⚠️ 未找到 Xray 核心文件"
fi

# 检查地理位置数据文件
if [ -f "/app/bin/geoip.dat" ] && [ -f "/app/bin/geosite.dat" ]; then
    echo "✅ 地理位置数据文件检查通过"
else
    echo "⚠️ 地理位置数据文件可能缺失"
fi

# 网络配置检查
echo "🌐 检查网络配置..."
if command -v iptables >/dev/null 2>&1; then
    echo "✅ iptables 可用"
else
    echo "⚠️ iptables 不可用，某些功能可能受限"
fi

# 设置信号处理
trap 'echo "🛑 收到停止信号，正在关闭服务..."; kill $PID; wait $PID; exit 0' TERM INT

echo "🎯 启动 3X-UI 主程序..."
echo "📍 主面板地址: http://localhost:2053"
echo "🛡️ 防火墙管理: http://localhost:5555 (如果启用)"
echo "────────────────────────────────────"

# 启动x-ui主程序
exec /app/x-ui &
PID=$!
wait $PID

# 3X-UI 完整使用说明

> 🛡️ 基于Xray Core的高性能代理面板 - 本地化优化版本

[![GitHub Release](https://img.shields.io/github/v/release/Li-yi-sen/3x-ui.svg)](https://github.com/Li-yi-sen/3x-ui/releases)
[![Go Report](https://goreportcard.com/badge/github.com/Li-yi-sen/3x-ui)](https://goreportcard.com/report/github.com/Li-yi-sen/3x-ui)
[![Downloads](https://img.shields.io/github/downloads/Li-yi-sen/3x-ui/total.svg)](https://github.com/Li-yi-sen/3x-ui/releases)
[![License](https://img.shields.io/badge/license-GPL%20V3-blue.svg)](https://raw.githubusercontent.com/Li-yi-sen/3x-ui/master/LICENSE)

## 📖 目录

- [项目概述](#-项目概述)
- [主要特性](#-主要特性)
- [本地化优势](#-本地化优势)
- [快速开始](#-快速开始)
- [安装指南](#-安装指南)
- [防火墙管理](#️-防火墙管理)
- [多语言支持](#-多语言支持)
- [使用教程](#-使用教程)
- [故障排除](#-故障排除)
- [贡献指南](#-贡献指南)
- [许可证](#-许可证)

---

## 🚀 项目概述

3X-UI 是一个基于 Xray Core 的高性能代理面板，提供了完整的 Web 管理界面和丰富的功能特性。本版本经过深度本地化优化，完全脱离了对远程资源的依赖，确保在任何网络环境下都能稳定运行。

### 🎯 设计理念
- **稳定可靠**: 完全本地化，避免网络依赖问题
- **简洁高效**: 精简多语言支持，专注核心功能
- **安全第一**: 独立防火墙管理，增强系统安全
- **易于维护**: 模块化设计，降低维护复杂度

---

## ✨ 主要特性

### 🔧 核心功能
- ✅ **Xray 配置管理**: 完整的 Xray 配置文件管理
- ✅ **多协议支持**: VMess, VLESS, Trojan, Shadowsocks, Dokodemo-door, Socks, HTTP
- ✅ **流量统计**: 实时流量监控和用户管理
- ✅ **系统监控**: CPU、内存、磁盘使用情况监控
- ✅ **用户管理**: 多用户管理，支持流量限制和到期时间
- ✅ **订阅服务**: 自动生成订阅链接，支持多种客户端

### 🛡️ 安全特性
- ✅ **TLS 支持**: 完整的 TLS 配置和证书管理
- ✅ **Reality 协议**: 支持最新的 Reality 协议
- ✅ **防火墙集成**: 独立的防火墙管理Web界面
- ✅ **IP 限制**: 支持 IP 访问限制和黑白名单
- ✅ **登录安全**: 支持双因子认证和 Secret Token

### 🌐 界面特性
- ✅ **现代 UI**: 基于 Ant Design Vue 的现代化界面
- ✅ **响应式设计**: 完美支持手机、平板、电脑
- ✅ **暗黑模式**: 支持明暗主题切换
- ✅ **多语言**: 支持中文和英文界面

---

## 🏠 本地化优势

### 🔄 完全离线运行
本版本经过深度本地化改造，实现了完全离线部署和运行：

#### ✅ 本地化特性
- ✅ **本地安装包**: 使用本地tar.gz安装包，无需在线下载
- ✅ **本地脚本**: 所有管理脚本本地化，避免网络依赖
- ✅ **本地资源**: Geo文件、工具脚本本地存储
- ✅ **独立防火墙**: 5555端口独立防火墙管理Web界面
- ✅ **简化语言**: 专注中英文双语支持，减少维护复杂度
- ✅ **本地版本管理**: 版本信息本地显示，不依赖GitHub API

### 📁 本地资源结构
```
3x-ui/
├── local-resources/              # 本地资源目录
│   ├── scripts/                  # 本地脚本
│   │   ├── local-install.sh     # 本地安装脚本
│   │   └── x-ui.sh              # 本地化管理脚本
│   ├── geo/                     # Geo数据文件
│   ├── tools/                   # 工具脚本
│   └── README.md               # 本地资源说明
├── web/firewall-server/         # 独立防火墙服务器
├── start-firewall-server.sh     # 防火墙服务启动脚本
├── stop-firewall-server.sh      # 防火墙服务停止脚本
├── firewall-quick-start.sh      # 防火墙快速启动脚本
└── local-install-entry.sh       # 主入口脚本
```

---

## 🚀 快速开始

### 📋 系统要求
- **操作系统**: Ubuntu 20.04+, Debian 11+, CentOS 8+, 或其他支持的Linux发行版
- **内存**: 至少 512MB RAM (推荐 1GB+)
- **存储**: 至少 1GB 可用空间
- **权限**: Root 权限
- **防火墙**: firewalld 或 ufw (可选，会自动安装)

### ⚡ 一键安装

#### 方式1: 使用主入口脚本 (推荐)
```bash
# 下载项目到本地
git clone https://github.com/Li-yi-sen/3x-ui.git
cd 3x-ui

# 确保安装包存在 (x-ui-linux-架构.tar.gz)
# 运行主入口脚本
bash local-install-entry.sh
```

#### 方式2: 直接运行本地安装
```bash
cd 3x-ui
bash local-resources/scripts/local-install.sh
```

#### 方式3: 使用快速启动脚本
```bash
cd 3x-ui
bash firewall-quick-start.sh  # 启动防火墙管理
```

#### 方式4: Docker Compose 部署 (最新)
```bash
# 克隆项目
git clone https://github.com/Li-yi-sen/3x-ui.git
cd 3x-ui

# 启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps
```

### 🎮 管理命令
安装完成后，可以使用以下命令管理：

```bash
x-ui                    # 进入管理菜单
x-ui start             # 启动面板
x-ui stop              # 停止面板  
x-ui restart           # 重启面板
x-ui status            # 查看状态
x-ui settings          # 查看设置
x-ui enable            # 开机启动
x-ui disable           # 禁用开机启动
x-ui log               # 查看日志
x-ui update            # 更新面板 (使用本地版本)
x-ui uninstall         # 卸载面板
```

---

## 📚 安装指南

### 🔧 详细安装步骤

#### 1. 环境准备
```bash
# 更新系统
sudo apt update && sudo apt upgrade -y   # Ubuntu/Debian
sudo yum update -y                       # CentOS/RHEL
sudo dnf update -y                       # Fedora

# 安装必要工具
sudo apt install wget curl tar -y        # Ubuntu/Debian
sudo yum install wget curl tar -y        # CentOS/RHEL
```

#### 2. 下载项目
```bash
# 克隆项目
git clone https://github.com/Li-yi-sen/3x-ui.git
cd 3x-ui

# 或者下载压缩包
wget https://github.com/Li-yi-sen/3x-ui/archive/refs/heads/main.zip
unzip main.zip
cd 3x-ui-main
```

#### 3. 准备安装包
```bash
# 下载对应架构的安装包到3x-ui根目录
# 例如：x-ui-linux-amd64.tar.gz
# 从 GitHub Releases 页面下载对应版本
```

#### 4. 执行安装
```bash
# 设置执行权限
chmod +x local-install-entry.sh

# 运行安装
sudo bash local-install-entry.sh
```

#### 5. 配置面板
安装完成后：
1. 浏览器访问 `http://您的服务器IP:2053`
2. 默认用户名: `admin`
3. 默认密码: `admin`
4. 首次登录请及时修改默认密码

### 🛠️ 自定义配置

#### 安装时自定义配置
```bash
# 在安装过程中可以自定义：
# - 用户名和密码
# - 访问端口
# - 访问路径
# - SSL证书设置
```

#### 安装后修改配置
```bash
x-ui                    # 进入管理菜单
# 选择对应选项：
# 6. 重置用户名和密码
# 7. 修改访问路径  
# 9. 修改面板端口
# 10. 查看面板设置
```

---

## 🛡️ 防火墙管理

### 🌟 独立防火墙管理系统

为了让防火墙管理更加清晰和独立，我们创建了一个运行在 **端口5555** 的独立防火墙管理Web界面。

#### ✨ 功能特点
- 🔥 **独立端口**: 运行在5555端口，与主面板分离
- 🌐 **专用界面**: 专门设计的防火墙管理界面  
- 🎯 **功能专一**: 专注于防火墙和端口管理
- ⚡ **实时操作**: 即时反馈操作结果
- 🎨 **现代设计**: 响应式Web界面，支持各种设备

#### 🚀 启动防火墙管理

##### 方式1: 通过x-ui菜单
```bash
x-ui
# 选择 26: 启动防火墙管理服务器
```

##### 方式2: 直接启动脚本
```bash
bash start-firewall-server.sh      # 启动
bash stop-firewall-server.sh       # 停止
```

##### 方式3: 快速启动
```bash
bash firewall-quick-start.sh       # 一键启动(包含环境检查)
```

##### 方式4: Docker Compose
```bash
docker-compose up -d firewall-server  # 启动防火墙容器
docker-compose logs -f firewall-server # 查看日志
```

#### 🌐 访问防火墙管理界面

- **本地访问**: `http://localhost:5555`
- **远程访问**: `http://您的服务器IP:5555`
- **侧栏访问**: 在3X-UI主面板侧栏点击"🛡️ 防火墙管理"

#### 🔧 防火墙管理功能

##### 状态管理
- **查看状态**: 显示当前防火墙类型(firewalld/ufw)和运行状态
- **启用防火墙**: 一键启用系统防火墙服务
- **实时刷新**: 自动获取最新防火墙状态

##### 端口管理
- **添加端口**: 输入端口号，选择协议(TCP/UDP)，一键添加
- **移除端口**: 在端口列表中一键移除指定端口
- **端口列表**: 以卡片形式显示所有开放端口
- **批量操作**: 支持端口范围操作

##### 支持的防火墙
- ✅ **firewalld** (CentOS/RHEL/Fedora)
- ✅ **ufw** (Ubuntu/Debian)
- 🔄 **自动检测**: 自动识别系统防火墙类型

#### 📁 防火墙服务文件结构
```
3x-ui/
├── web/firewall-server/
│   ├── main.go                    # Go服务器源码
│   ├── go.mod                     # Go模块配置
│   ├── Dockerfile                 # Docker构建文件
│   ├── .dockerignore              # Docker忽略文件
│   ├── firewall-server           # 编译后的可执行文件
│   ├── firewall-server.log       # 运行日志
│   └── firewall-server.pid       # 进程ID文件
├── start-firewall-server.sh      # 启动脚本
├── stop-firewall-server.sh       # 停止脚本
└── firewall-quick-start.sh       # 快速启动脚本
```

#### 🔍 故障排除

##### 编译问题
```bash
# 检查Go环境
go version

# 如果没有Go，快速启动脚本会自动安装
bash firewall-quick-start.sh
```

##### 端口占用
```bash
# 检查端口占用
lsof -i:5555
netstat -tulpn | grep 5555

# 停止占用进程
bash stop-firewall-server.sh
```

##### 权限问题
```bash
# 防火墙管理需要root权限
sudo bash start-firewall-server.sh
```

---

## 🌍 多语言支持

### 🎯 精简的双语支持

本版本专注于核心语言支持，提供高质量的双语体验：

#### ✅ 支持的语言
- 🇨🇳 **简体中文** (zh_CN) - 主要面向中国用户
- 🇺🇸 **英语** (en_US) - 面向国际用户

#### 📊 双语优势
- **存储优化**: 精简的语言包，提升加载速度
- **维护便利**: 专注双语翻译质量，降低维护复杂度
- **用户体验**: 两种主要语言完整覆盖目标用户群体

#### 🔄 智能语言检测
- **Cookie优先**: 优先使用用户设置的语言Cookie
- **浏览器检测**: 自动检测浏览器语言偏好
- **智能切换**: 在中英文之间自动切换
- **默认语言**: 英语 (en_US)

---

## 📖 使用教程

### 🔧 基础配置

#### 1. 首次登录设置
```bash
# 访问面板
http://您的服务器IP:2053

# 默认登录信息
用户名: admin
密码: admin

# 首次登录后务必：
1. 修改默认密码
2. 设置访问路径
3. 配置SSL证书(可选)
```

#### 2. 用户管理
```bash
# 在面板中添加用户
1. 点击"入站"菜单
2. 点击"添加入站"
3. 选择协议类型
4. 配置参数
5. 添加用户
```

#### 3. 流量监控
```bash
# 查看流量统计
1. 在"概览"页面查看总体流量
2. 在"入站"页面查看单个入站流量
3. 支持按时间段查看流量历史
```

### 🛠️ 高级配置

#### SSL证书配置
```bash
# 自动申请证书
x-ui
# 选择 18: SSL证书管理

# 手动配置证书
1. 将证书文件上传到服务器
2. 在面板设置中配置证书路径
3. 重启面板生效
```

#### 订阅服务配置
```bash
# 配置订阅服务
1. 在设置页面启用订阅服务
2. 设置订阅路径和密钥
3. 配置订阅模板
4. 生成订阅链接
```

#### 系统监控配置
```bash
# 启用系统监控
1. 在设置中启用CPU/内存监控
2. 设置监控间隔
3. 配置告警阈值
4. 启用邮件通知(可选)
```

### 🔄 维护操作

#### 数据备份
```bash
# 备份数据库
cp /usr/local/x-ui/bin/x-ui.db /path/to/backup/

# 备份配置文件
cp -r /usr/local/x-ui/ /path/to/backup/x-ui-backup/
```

#### 日志管理
```bash
# 查看运行日志
x-ui log

# 查看系统日志
journalctl -u x-ui -f

# 清理日志
journalctl --vacuum-time=7d
```

#### 性能优化
```bash
# 启用BBR加速
x-ui
# 选择 22: 启用BBR

# 更新Geo文件
x-ui  
# 选择 23: 更新Geo文件
```

---

## 🔍 故障排除

### 🚨 常见问题

#### 1. 安装失败
```bash
# 检查系统要求
- 确保系统版本符合要求
- 确保有root权限
- 确保网络连接正常

# 检查安装包
- 确保x-ui-linux-架构.tar.gz存在
- 确保安装包完整无损坏
- 检查架构是否匹配

# 重新安装
bash local-resources/scripts/local-install.sh
```

#### 2. 面板无法访问
```bash
# 检查服务状态
systemctl status x-ui

# 检查端口占用
netstat -tulpn | grep 2053

# 检查防火墙设置
firewall-cmd --list-ports
ufw status

# 重启服务
systemctl restart x-ui
```

#### 3. 防火墙管理无法启动
```bash
# 检查Go环境
go version

# 检查端口占用
lsof -i:5555

# 手动编译
cd web/firewall-server
go build -o firewall-server main.go

# 检查权限
ls -la firewall-server
chmod +x firewall-server
```

#### 4. 用户连接失败
```bash
# 检查配置
1. 确认入站配置正确
2. 检查用户凭据
3. 验证端口开放状态
4. 确认协议设置

# 检查日志
tail -f /var/log/x-ui.log
```

#### 5. Docker 相关问题
```bash
# 检查容器状态
docker-compose ps

# 查看容器日志
docker-compose logs -f 3xui
docker-compose logs -f firewall-server

# 重新构建镜像
docker-compose build --no-cache
docker-compose up -d
```

### 🔧 性能问题

#### 内存占用过高
```bash
# 优化配置
1. 减少并发连接数
2. 调整日志级别
3. 清理无用用户
4. 重启服务

# 检查内存使用
free -h
ps aux | grep xray
```

#### 网络延迟高
```bash
# 网络优化
1. 启用BBR加速
2. 调整MTU值
3. 优化路由配置
4. 检查DNS设置

# 测试网络
ping 目标地址
traceroute 目标地址
```

### 📞 获取帮助

#### 日志收集
```bash
# 收集系统信息
uname -a
cat /etc/os-release

# 收集服务日志
journalctl -u x-ui --no-pager
tail -100 /var/log/x-ui.log

# 收集配置信息
x-ui settings
```

#### 社区支持
- **GitHub Issues**: [提交问题报告](https://github.com/Li-yi-sen/3x-ui/issues)
- **讨论区**: 在GitHub讨论区寻求帮助
- **文档**: 查看完整的在线文档

---

## 🤝 贡献指南

### 📋 如何贡献

#### 🐛 报告问题
1. 在GitHub上创建Issue
2. 详细描述问题现象
3. 提供复现步骤
4. 附上相关日志信息

#### 🔧 提交代码
1. Fork项目到您的账户
2. 创建功能分支
3. 提交您的修改
4. 创建Pull Request

#### 📝 改进文档
1. 发现文档错误或不足
2. 提交修改建议
3. 翻译文档到其他语言
4. 添加使用示例

### 🎯 开发指南

#### 环境搭建
```bash
# 克隆项目
git clone https://github.com/Li-yi-sen/3x-ui.git
cd 3x-ui

# 安装依赖
go mod download

# 构建项目
go build -o x-ui main.go
```

#### 代码规范
- 遵循Go语言编码规范
- 添加必要的注释
- 编写单元测试
- 确保代码质量

#### 测试指南
```bash
# 运行测试
go test ./...

# 代码覆盖率
go test -cover ./...

# 性能测试
go test -bench=. ./...
```

---

## 📄 许可证

本项目基于 [GPL v3 License](LICENSE) 开源。

### 🔖 版权信息
- **原作者**: 3X-UI 社区
- **本地化优化**: Li-yi-sen
- **贡献者**: 所有参与开发的贡献者

### ⚖️ 使用条款
- ✅ 自由使用、修改和分发
- ✅ 可用于商业用途
- ❌ 不提供任何担保
- 📋 修改后的代码必须开源

---

## 🙏 致谢

感谢以下项目和社区的支持：

- **[Xray-core](https://github.com/XTLS/Xray-core)** - 核心代理程序
- **[3X-UI](https://github.com/MHSanaei/3x-ui)** - 原始项目
- **Ant Design Vue** - UI框架
- **Gin** - Web框架
- **所有贡献者** - 感谢每一位贡献者的努力

---

## 📞 联系方式

- **项目地址**: [https://github.com/Li-yi-sen/3x-ui](https://github.com/Li-yi-sen/3x-ui)
- **Issue反馈**: [GitHub Issues](https://github.com/Li-yi-sen/3x-ui/issues)
- **讨论社区**: [GitHub Discussions](https://github.com/Li-yi-sen/3x-ui/discussions)

---

## 🔔 更新日志

### 🆕 最新版本特性 (v2.0)
- ✅ **Docker 版本更新**: 全面更新Docker配置和依赖版本
  - Go版本: `golang:alpine` → `golang:1.23-alpine`
  - 基础镜像: `alpine` → `alpine:3.20`
  - Nginx镜像: `nginx:alpine` → `nginx:1.27-alpine`
  - Xray核心: `v25.7.26` → `v25.12.31`

- ✅ **依赖版本优化**: 
  - 更新Telegram SDK: `v0.32.0` → `v0.34.0`
  - 更新Xray核心依赖: `v1.250726.0` → `v1.251231.0`
  - 修复防火墙服务器依赖问题

- ✅ **容器化增强**:
  - 添加健康检查机制
  - 完善的多阶段构建
  - 优化的权限和安全配置
  - 独立的防火墙服务器容器

- ✅ **构建优化**:
  - 添加`.dockerignore`文件减少构建体积
  - 国内Go代理加速构建
  - 多源下载和CDN备份
  - 完善的错误处理和重试机制

### 🔄 v1.5 版本特性
- ✅ 完全本地化部署，移除所有远程依赖
- ✅ 独立防火墙管理Web界面(端口5555)
- ✅ 简化多语言支持，只保留中英文
- ✅ 优化安装流程，支持一键部署
- ✅ 增强安全性，独立模块设计

### 📚 相关文档
- **[📦 部署说明](部署说明.md)** - 详细的下载和部署指南
- **[🔄 版本更新说明](版本更新说明.md)** - Docker和依赖版本更新详情
- **[📋 MD文件整合说明](MD文件整合说明.md)** - 文档结构优化说明
- **[🧹 MD文件清理总结](MD文件清理总结.md)** - 文档优化和代码本地化清理总结

### 升级指南
```bash
# 从旧版本升级 (本地安装)
x-ui
# 选择 2: 更新面板 (使用本地版本)

# 或手动升级
bash local-resources/scripts/local-install.sh

# Docker版本升级
docker-compose pull
docker-compose down
docker-compose up -d --build
```

---

**🎉 感谢您选择 3X-UI 本地化优化版本！**

> 如果觉得项目有用，请给我们一个 ⭐Star，这是对我们最大的鼓励！ 
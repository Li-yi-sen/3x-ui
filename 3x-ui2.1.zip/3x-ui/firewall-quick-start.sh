#!/bin/bash

# 3X-UI 防火墙管理快速启动脚本
# 一键启动独立的防火墙管理Web界面

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
purple='\033[0;35m'
cyan='\033[0;36m'
plain='\033[0m'

# 显示欢迎横幅
show_banner() {
    clear
    echo -e "${cyan}╔══════════════════════════════════════════════════════════════╗${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}║           ${green}🛡️  3X-UI 防火墙管理系统 🛡️${cyan}                   ║${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}║              ${yellow}独立 • 安全 • 便捷 • 高效${cyan}                    ║${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}╚══════════════════════════════════════════════════════════════╝${plain}"
    echo ""
}

# 检查系统环境
check_environment() {
    echo -e "${blue}🔍 正在检查系统环境...${plain}"
    
    # 检查root权限
    if [[ $EUID -ne 0 ]]; then
        echo -e "${red}❌ 错误: 防火墙管理需要 root 权限${plain}"
        echo -e "${yellow}💡 请使用: sudo bash $0${plain}"
        exit 1
    fi
    
    # 检查Go环境
    if ! command -v go &> /dev/null; then
        echo -e "${red}❌ 未找到Go编译器${plain}"
        echo -e "${yellow}📥 正在尝试安装Go...${plain}"
        install_go
    else
        local go_version=$(go version | awk '{print $3}' | cut -c 3-)
        echo -e "${green}✅ Go环境: ${go_version}${plain}"
    fi
    
    # 检查防火墙工具
    if command -v firewall-cmd &> /dev/null; then
        echo -e "${green}✅ 防火墙: firewalld${plain}"
    elif command -v ufw &> /dev/null; then
        echo -e "${green}✅ 防火墙: ufw${plain}"
    else
        echo -e "${yellow}⚠️  未检测到firewalld或ufw，将尝试安装${plain}"
        install_firewall
    fi
    
    echo -e "${green}🎯 环境检查完成${plain}"
    echo ""
}

# 安装Go (简化版)
install_go() {
    local os_type=$(uname -s | tr '[:upper:]' '[:lower:]')
    local arch_type=$(uname -m)
    
    case $arch_type in
        x86_64) arch_type="amd64" ;;
        aarch64) arch_type="arm64" ;;
        armv7l) arch_type="armv6l" ;;
    esac
    
    local go_url="https://go.dev/dl/go1.20.linux-${arch_type}.tar.gz"
    
    echo -e "${blue}📥 下载Go编译器...${plain}"
    wget -q --show-progress "$go_url" -O go.tar.gz
    
    if [[ $? -eq 0 ]]; then
        rm -rf /usr/local/go
        tar -C /usr/local -xzf go.tar.gz
        rm go.tar.gz
        
        # 添加到PATH
        if ! grep -q "/usr/local/go/bin" /etc/profile; then
            echo 'export PATH=$PATH:/usr/local/go/bin' >> /etc/profile
        fi
        
        export PATH=$PATH:/usr/local/go/bin
        echo -e "${green}✅ Go安装成功${plain}"
    else
        echo -e "${red}❌ Go安装失败，请手动安装${plain}"
        exit 1
    fi
}

# 安装防火墙
install_firewall() {
    if command -v apt &> /dev/null; then
        echo -e "${blue}📦 安装ufw...${plain}"
        apt update && apt install -y ufw
    elif command -v yum &> /dev/null; then
        echo -e "${blue}📦 安装firewalld...${plain}"
        yum install -y firewalld
        systemctl enable firewalld
    elif command -v dnf &> /dev/null; then
        echo -e "${blue}📦 安装firewalld...${plain}"
        dnf install -y firewalld
        systemctl enable firewalld
    else
        echo -e "${red}❌ 无法自动安装防火墙，请手动安装${plain}"
    fi
}

# 启动防火墙管理服务器
start_firewall_server() {
    echo -e "${blue}🚀 正在启动防火墙管理服务器...${plain}"
    
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    local start_script="$script_dir/start-firewall-server.sh"
    
    if [[ -f "$start_script" ]]; then
        bash "$start_script"
    else
        echo -e "${red}❌ 启动脚本未找到: $start_script${plain}"
        exit 1
    fi
}

# 显示访问信息
show_access_info() {
    local server_ip=$(hostname -I | awk '{print $1}' 2>/dev/null || echo "localhost")
    
    echo ""
    echo -e "${cyan}╔══════════════════════════════════════════════════════════════╗${plain}"
    echo -e "${cyan}║                    ${green}🎉 启动成功！${cyan}                          ║${plain}"
    echo -e "${cyan}╠══════════════════════════════════════════════════════════════╣${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}║  ${yellow}🌐 本地访问:${plain} ${blue}http://localhost:5555${cyan}                  ║${plain}"
    echo -e "${cyan}║  ${yellow}🌍 远程访问:${plain} ${blue}http://${server_ip}:5555${cyan}        ║${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}║  ${yellow}📋 管理方式:${plain}                                         ║${plain}"
    echo -e "${cyan}║    • 在3X-UI侧栏点击"防火墙管理"                         ║${plain}"
    echo -e "${cyan}║    • 直接浏览器访问上述地址                              ║${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}║  ${yellow}🛑 停止服务:${plain} ${blue}bash stop-firewall-server.sh${cyan}         ║${plain}"
    echo -e "${cyan}║                                                              ║${plain}"
    echo -e "${cyan}╚══════════════════════════════════════════════════════════════╝${plain}"
    echo ""
}

# 主程序
main() {
    show_banner
    
    echo -e "${purple}🎯 欢迎使用3X-UI防火墙管理系统${plain}"
    echo -e "${yellow}📝 本系统提供独立的防火墙管理Web界面，运行在端口5555${plain}"
    echo ""
    
    # 确认继续
    read -p "是否继续启动防火墙管理服务器? (Y/n): " -n 1 -r
    echo
    
    if [[ $REPLY =~ ^[Nn]$ ]]; then
        echo -e "${yellow}👋 已取消启动${plain}"
        exit 0
    fi
    
    check_environment
    start_firewall_server
    
    # 检查是否启动成功
    sleep 3
    if netstat -tuln 2>/dev/null | grep -q ":5555 " || ss -tuln 2>/dev/null | grep -q ":5555 "; then
        show_access_info
    else
        echo -e "${red}❌ 服务器启动可能失败，请检查日志${plain}"
    fi
}

# 运行主程序
main "$@" 
#!/bin/bash

# 防火墙管理服务器停止脚本

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
plain='\033[0m'

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIREWALL_SERVER_DIR="$SCRIPT_DIR/web/firewall-server"
PID_FILE="$FIREWALL_SERVER_DIR/firewall-server.pid"

echo -e "${blue}🛑 正在停止防火墙管理服务器...${plain}"

# 检查PID文件是否存在
if [[ -f "$PID_FILE" ]]; then
    PID=$(cat "$PID_FILE")
    
    if kill -0 "$PID" 2>/dev/null; then
        # 进程存在，停止它
        echo -e "${yellow}📋 发现运行中的服务器进程 (PID: $PID)${plain}"
        
        kill "$PID"
        
        # 等待进程结束
        for i in {1..10}; do
            if ! kill -0 "$PID" 2>/dev/null; then
                break
            fi
            echo -e "${yellow}⏳ 等待进程结束... ($i/10)${plain}"
            sleep 1
        done
        
        # 检查进程是否还在运行
        if kill -0 "$PID" 2>/dev/null; then
            echo -e "${red}⚠️  进程未响应，强制终止...${plain}"
            kill -9 "$PID"
            sleep 1
        fi
        
        if ! kill -0 "$PID" 2>/dev/null; then
            echo -e "${green}✅ 防火墙服务器已停止${plain}"
            rm -f "$PID_FILE"
        else
            echo -e "${red}❌ 无法停止进程${plain}"
            exit 1
        fi
    else
        echo -e "${yellow}⚠️  PID文件存在但进程已不存在，清理PID文件${plain}"
        rm -f "$PID_FILE"
    fi
else
    # 尝试通过端口查找进程
    PID=$(lsof -t -i:5555 2>/dev/null)
    
    if [[ -n "$PID" ]]; then
        echo -e "${yellow}📋 通过端口发现防火墙服务器进程 (PID: $PID)${plain}"
        
        if kill "$PID" 2>/dev/null; then
            sleep 2
            if ! kill -0 "$PID" 2>/dev/null; then
                echo -e "${green}✅ 防火墙服务器已停止${plain}"
            else
                echo -e "${red}⚠️  强制终止进程...${plain}"
                kill -9 "$PID"
                echo -e "${green}✅ 防火墙服务器已强制停止${plain}"
            fi
        else
            echo -e "${red}❌ 无法停止进程${plain}"
            exit 1
        fi
    else
        echo -e "${yellow}ℹ️  没有发现运行中的防火墙服务器${plain}"
    fi
fi

# 清理可能的临时文件
if [[ -f "$FIREWALL_SERVER_DIR/firewall-server.log" ]]; then
    echo -e "${blue}📄 日志文件保留在: $FIREWALL_SERVER_DIR/firewall-server.log${plain}"
fi

echo -e "${green}🎉 防火墙管理服务器停止完成${plain}" 
package controller

import (
	"strconv"

	"x-ui/web/service"
	"x-ui/web/session"

	"github.com/gin-gonic/gin"
)

type FirewallController struct {
	firewallService service.FirewallService
	inboundService  service.InboundService
}

func NewFirewallController(g *gin.RouterGroup) *FirewallController {
	a := &FirewallController{}
	a.initRouter(g)
	return a
}

func (a *FirewallController) initRouter(g *gin.RouterGroup) {
	g = g.Group("/firewall")

	g.POST("/activatePort", a.activatePort)
	g.POST("/removePort", a.removePort)
	g.GET("/status", a.getFirewallStatus)
	g.GET("/ports", a.getOpenPorts)
	g.POST("/inbound/:id/activate", a.activateInboundPort)
}

// activatePort 激活指定端口
func (a *FirewallController) activatePort(c *gin.Context) {
	user := session.GetLoginUser(c)
	if user == nil {
		jsonMsg(c, "请先登录", nil)
		return
	}

	portStr := c.PostForm("port")
	if portStr == "" {
		jsonMsg(c, "端口号不能为空", nil)
		return
	}

	port, err := a.firewallService.ValidatePortString(portStr)
	if err != nil {
		jsonMsg(c, "端口号无效", err)
		return
	}

	err = a.firewallService.ActivateInboundPort(port)
	if err != nil {
		jsonMsg(c, "激活端口失败", err)
		return
	}

	jsonMsgObj(c, "端口激活成功", gin.H{"port": port}, nil)
}

// removePort 移除指定端口
func (a *FirewallController) removePort(c *gin.Context) {
	user := session.GetLoginUser(c)
	if user == nil {
		jsonMsg(c, "请先登录", nil)
		return
	}

	portStr := c.PostForm("port")
	protocol := c.DefaultPostForm("protocol", "tcp")

	port, err := a.firewallService.ValidatePortString(portStr)
	if err != nil {
		jsonMsg(c, "端口号无效", err)
		return
	}

	err = a.firewallService.RemovePort(port, protocol)
	if err != nil {
		jsonMsg(c, "移除端口失败", err)
		return
	}

	jsonMsgObj(c, "端口移除成功", gin.H{"port": port}, nil)
}

// getFirewallStatus 获取防火墙状态
func (a *FirewallController) getFirewallStatus(c *gin.Context) {
	user := session.GetLoginUser(c)
	if user == nil {
		jsonMsg(c, "请先登录", nil)
		return
	}

	status, err := a.firewallService.GetFirewallStatus()
	if err != nil {
		jsonMsg(c, "获取防火墙状态失败", err)
		return
	}

	jsonObj(c, status, nil)
}

// getOpenPorts 获取开放端口列表
func (a *FirewallController) getOpenPorts(c *gin.Context) {
	user := session.GetLoginUser(c)
	if user == nil {
		jsonMsg(c, "请先登录", nil)
		return
	}

	ports, err := a.firewallService.GetOpenPorts()
	if err != nil {
		jsonMsg(c, "获取端口列表失败", err)
		return
	}

	jsonObj(c, gin.H{"ports": ports}, nil)
}

// activateInboundPort 激活入站规则端口（给入站管理页面使用）
func (a *FirewallController) activateInboundPort(c *gin.Context) {
	user := session.GetLoginUser(c)
	if user == nil {
		jsonMsg(c, "请先登录", nil)
		return
	}

	idStr := c.Param("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		jsonMsg(c, "入站规则ID无效", err)
		return
	}

	// 获取入站规则信息
	inbound, err := a.inboundService.GetInbound(id)
	if err != nil {
		jsonMsg(c, "获取入站规则失败", err)
		return
	}

	// 激活端口
	err = a.firewallService.ActivateInboundPort(inbound.Port)
	if err != nil {
		jsonMsg(c, "激活端口失败", err)
		return
	}

	jsonMsgObj(c, "入站端口激活成功", gin.H{
		"inboundId": id,
		"port":      inbound.Port,
	}, nil)
} 
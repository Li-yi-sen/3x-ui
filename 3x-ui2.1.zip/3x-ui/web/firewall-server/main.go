package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
)

// FirewallType 防火墙类型
type FirewallType string

const (
	FirewallTypeFirewalld FirewallType = "firewalld"
	FirewallTypeUfw       FirewallType = "ufw"
	FirewallTypeNone      FirewallType = "none"
)

// FirewallStatus 防火墙状态
type FirewallStatus struct {
	Type       FirewallType `json:"type"`
	Active     bool         `json:"active"`
	OpenPorts  []string     `json:"open_ports"`
	Message    string       `json:"message"`
}

// FirewallService 防火墙服务
type FirewallService struct{}

// detectFirewall 检测系统中的防火墙类型
func (s *FirewallService) detectFirewall() FirewallType {
	if s.commandExists("firewall-cmd") {
		return FirewallTypeFirewalld
	} else if s.commandExists("ufw") {
		return FirewallTypeUfw
	}
	return FirewallTypeNone
}

// commandExists 检查命令是否存在
func (s *FirewallService) commandExists(cmd string) bool {
	_, err := exec.LookPath(cmd)
	return err == nil
}

// isFirewallActive 检查防火墙是否激活
func (s *FirewallService) isFirewallActive() (bool, error) {
	fwType := s.detectFirewall()

	switch fwType {
	case FirewallTypeFirewalld:
		cmd := exec.Command("systemctl", "is-active", "--quiet", "firewalld")
		return cmd.Run() == nil, nil
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "status")
		output, err := cmd.Output()
		if err != nil {
			return false, err
		}
		return strings.Contains(string(output), "Status: active"), nil
	default:
		return false, fmt.Errorf("unsupported firewall type")
	}
}

// enableFirewall 启用防火墙
func (s *FirewallService) enableFirewall() error {
	fwType := s.detectFirewall()

	switch fwType {
	case FirewallTypeFirewalld:
		cmd := exec.Command("systemctl", "enable", "--now", "firewalld")
		return cmd.Run()
	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "--force", "enable")
		return cmd.Run()
	default:
		return fmt.Errorf("unsupported firewall type")
	}
}

// addPort 添加端口
func (s *FirewallService) addPort(port int, protocol string) error {
	if protocol == "" {
		protocol = "tcp"
	}

	fwType := s.detectFirewall()

	switch fwType {
	case FirewallTypeFirewalld:
		// 添加永久规则
		cmd1 := exec.Command("firewall-cmd", "--permanent", "--add-port", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd1.Run(); err != nil {
			return err
		}

		// 重新加载
		cmd2 := exec.Command("firewall-cmd", "--reload")
		if err := cmd2.Run(); err != nil {
			return err
		}

		// 验证端口是否已添加
		cmd3 := exec.Command("firewall-cmd", "--query-port", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd3.Run(); err != nil {
			return fmt.Errorf("端口添加失败")
		}

		log.Printf("端口 %d/%s 已成功通过 firewalld 激活", port, protocol)
		return nil

	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "allow", fmt.Sprintf("%d/%s", port, protocol))
		return cmd.Run()

	default:
		return fmt.Errorf("unsupported firewall type")
	}
}

// removePort 移除端口
func (s *FirewallService) removePort(port int, protocol string) error {
	if protocol == "" {
		protocol = "tcp"
	}

	fwType := s.detectFirewall()

	switch fwType {
	case FirewallTypeFirewalld:
		cmd1 := exec.Command("firewall-cmd", "--permanent", "--remove-port", fmt.Sprintf("%d/%s", port, protocol))
		if err := cmd1.Run(); err != nil {
			return err
		}

		cmd2 := exec.Command("firewall-cmd", "--reload")
		if err := cmd2.Run(); err != nil {
			return err
		}

		log.Printf("端口 %d/%s 已从 firewalld 移除", port, protocol)
		return nil

	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "delete", "allow", fmt.Sprintf("%d/%s", port, protocol))
		return cmd.Run()

	default:
		return fmt.Errorf("unsupported firewall type")
	}
}

// getOpenPorts 获取开放端口列表
func (s *FirewallService) getOpenPorts() ([]string, error) {
	fwType := s.detectFirewall()

	switch fwType {
	case FirewallTypeFirewalld:
		cmd := exec.Command("firewall-cmd", "--list-ports")
		output, err := cmd.Output()
		if err != nil {
			return nil, fmt.Errorf("获取firewalld端口列表失败: %v", err)
		}

		portsStr := strings.TrimSpace(string(output))
		if portsStr == "" {
			return []string{}, nil
		}

		ports := strings.Fields(portsStr)
		return ports, nil

	case FirewallTypeUfw:
		cmd := exec.Command("ufw", "status", "numbered")
		output, err := cmd.Output()
		if err != nil {
			return nil, fmt.Errorf("获取ufw端口列表失败: %v", err)
		}

		var ports []string
		lines := strings.Split(string(output), "\n")
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if strings.Contains(line, "ALLOW IN") && strings.Contains(line, "/tcp") {
				// 简单解析ufw输出
				parts := strings.Fields(line)
				if len(parts) > 0 {
					ports = append(ports, parts[0])
				}
			}
		}
		return ports, nil

	default:
		return nil, fmt.Errorf("unsupported firewall type")
	}
}

// getFirewallStatus 获取防火墙状态
func (s *FirewallService) getFirewallStatus() (*FirewallStatus, error) {
	fwType := s.detectFirewall()
	active, err := s.isFirewallActive()
	if err != nil {
		return nil, err
	}

	openPorts := []string{}
	if active {
		openPorts, _ = s.getOpenPorts()
	}

	var message string
	if fwType == FirewallTypeNone {
		message = "未检测到支持的防火墙"
	} else if !active {
		message = "防火墙未激活"
	} else {
		message = "防火墙正常运行"
	}

	return &FirewallStatus{
		Type:      fwType,
		Active:    active,
		OpenPorts: openPorts,
		Message:   message,
	}, nil
}

var firewallService = &FirewallService{}

// 处理首页
func indexHandler(w http.ResponseWriter, r *http.Request) {
	tmpl := `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>防火墙管理 - 3X-UI</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px 0;
            text-align: center;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 300;
        }
        
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .status-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-left: 4px solid #667eea;
        }
        
        .status-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .status-active {
            background: #f6ffed;
            color: #52c41a;
            border: 1px solid #b7eb8f;
        }
        
        .status-inactive {
            background: #fff2f0;
            color: #ff4d4f;
            border: 1px solid #ffccc7;
        }
        
        .ports-section {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .section-title {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 10px;
        }
        
        .port-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .port-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
        }
        
        .port-item:hover {
            background: #e9ecef;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .port-number {
            font-family: 'Monaco', 'Menlo', monospace;
            font-weight: bold;
            font-size: 16px;
            color: #667eea;
        }
        
        .controls {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            gap: 15px;
            align-items: end;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        
        input, select, button {
            padding: 12px 16px;
            border: 2px solid #e1e5e9;
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        input:focus, select:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        button {
            background: #667eea;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 500;
            min-width: 120px;
        }
        
        button:hover {
            background: #5a6fd8;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        
        .btn-danger {
            background: #ff4d4f;
        }
        
        .btn-danger:hover {
            background: #ff7875;
        }
        
        .btn-success {
            background: #52c41a;
        }
        
        .btn-success:hover {
            background: #73d13d;
        }
        
        .message {
            padding: 15px;
            border-radius: 6px;
            margin: 15px 0;
            display: none;
        }
        
        .message.success {
            background: #f6ffed;
            color: #52c41a;
            border: 1px solid #b7eb8f;
        }
        
        .message.error {
            background: #fff2f0;
            color: #ff4d4f;
            border: 1px solid #ffccc7;
        }
        
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }
        
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .remove-btn {
            background: #ff4d4f;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
        }
        
        .remove-btn:hover {
            background: #ff7875;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .back-link {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255,255,255,0.9);
            padding: 10px 20px;
            border-radius: 25px;
            text-decoration: none;
            color: #667eea;
            font-weight: 500;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .back-link:hover {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }
    </style>
</head>
<body>
    <a href="javascript:history.back()" class="back-link">← 返回主面板</a>
    
    <div class="container">
        <div class="header">
            <h1>🛡️ 防火墙管理</h1>
            <p>集中管理服务器防火墙端口规则</p>
        </div>
        
        <div class="status-card">
            <div class="status-header">
                <h3>防火墙状态</h3>
                <span id="status-badge" class="status-badge">检测中...</span>
            </div>
            <p id="status-message">正在获取防火墙状态...</p>
        </div>
        
        <div class="ports-section">
            <h3 class="section-title">开放端口列表</h3>
            <div id="loading" class="loading">
                <div class="spinner"></div>
                <p>加载中...</p>
            </div>
            <div id="ports-list" class="port-list"></div>
            <div id="empty-state" class="empty-state" style="display: none;">
                <p>暂无开放端口</p>
            </div>
        </div>
        
        <div class="controls">
            <h3 class="section-title">端口管理</h3>
            <div id="message" class="message"></div>
            
            <div class="form-group">
                <div class="form-row">
                    <div>
                        <label for="port">端口号</label>
                        <input type="number" id="port" placeholder="例: 8080" min="1" max="65535">
                    </div>
                    <div>
                        <label for="protocol">协议</label>
                        <select id="protocol">
                            <option value="tcp">TCP</option>
                            <option value="udp">UDP</option>
                        </select>
                    </div>
                    <div>
                        <label>&nbsp;</label>
                        <button onclick="addPort()" class="btn-success">添加端口</button>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <button onclick="enableFirewall()" class="btn-primary">启用防火墙</button>
                <button onclick="refreshStatus()" style="background: #1890ff;">刷新状态</button>
            </div>
        </div>
    </div>

    <script>
        // 全局状态
        let currentStatus = null;

        // 页面加载完成后初始化
        document.addEventListener('DOMContentLoaded', function() {
            refreshStatus();
        });

        // 刷新防火墙状态
        async function refreshStatus() {
            try {
                document.getElementById('loading').style.display = 'block';
                
                const response = await fetch('/api/status');
                const data = await response.json();
                
                currentStatus = data;
                updateStatusDisplay(data);
                updatePortsList(data.open_ports || []);
                
            } catch (error) {
                showMessage('获取状态失败: ' + error.message, 'error');
            } finally {
                document.getElementById('loading').style.display = 'none';
            }
        }

        // 更新状态显示
        function updateStatusDisplay(status) {
            const badge = document.getElementById('status-badge');
            const message = document.getElementById('status-message');
            
            if (status.active) {
                badge.textContent = '运行中';
                badge.className = 'status-badge status-active';
            } else {
                badge.textContent = '未激活';
                badge.className = 'status-badge status-inactive';
            }
            
            message.textContent = status.message + ' (类型: ' + status.type + ')';
        }

        // 更新端口列表
        function updatePortsList(ports) {
            const portsList = document.getElementById('ports-list');
            const emptyState = document.getElementById('empty-state');
            
            if (ports.length === 0) {
                portsList.innerHTML = '';
                emptyState.style.display = 'block';
                return;
            }
            
            emptyState.style.display = 'none';
            
            portsList.innerHTML = ports.map(port => {
                return '<div class="port-item">' +
                    '<span class="port-number">' + port + '</span>' +
                    '<button class="remove-btn" onclick="removePort(\'' + port + '\')">移除</button>' +
                    '</div>';
            }).join('');
        }

        // 添加端口
        async function addPort() {
            const port = document.getElementById('port').value;
            const protocol = document.getElementById('protocol').value;
            
            if (!port) {
                showMessage('请输入端口号', 'error');
                return;
            }
            
            try {
                const response = await fetch('/api/add-port', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        port: parseInt(port),
                        protocol: protocol
                    })
                });
                
                const result = await response.json();
                
                if (response.ok) {
                    showMessage('端口添加成功', 'success');
                    document.getElementById('port').value = '';
                    refreshStatus();
                } else {
                    showMessage('端口添加失败: ' + result.error, 'error');
                }
                
            } catch (error) {
                showMessage('端口添加失败: ' + error.message, 'error');
            }
        }

        // 移除端口
        async function removePort(portStr) {
            if (!confirm('确定要移除端口 ' + portStr + ' 吗？')) {
                return;
            }
            
            const [port, protocol] = portStr.split('/');
            
            try {
                const response = await fetch('/api/remove-port', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        port: parseInt(port),
                        protocol: protocol || 'tcp'
                    })
                });
                
                const result = await response.json();
                
                if (response.ok) {
                    showMessage('端口移除成功', 'success');
                    refreshStatus();
                } else {
                    showMessage('端口移除失败: ' + result.error, 'error');
                }
                
            } catch (error) {
                showMessage('端口移除失败: ' + error.message, 'error');
            }
        }

        // 启用防火墙
        async function enableFirewall() {
            if (!confirm('确定要启用防火墙吗？这可能会影响网络连接。')) {
                return;
            }
            
            try {
                const response = await fetch('/api/enable', {
                    method: 'POST'
                });
                
                const result = await response.json();
                
                if (response.ok) {
                    showMessage('防火墙启用成功', 'success');
                    refreshStatus();
                } else {
                    showMessage('防火墙启用失败: ' + result.error, 'error');
                }
                
            } catch (error) {
                showMessage('防火墙启用失败: ' + error.message, 'error');
            }
        }

        // 显示消息
        function showMessage(text, type) {
            const message = document.getElementById('message');
            message.textContent = text;
            message.className = 'message ' + type;
            message.style.display = 'block';
            
            setTimeout(() => {
                message.style.display = 'none';
            }, 5000);
        }
    </script>
</body>
</html>
	`
	
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write([]byte(tmpl))
}

// API处理器
func statusHandler(w http.ResponseWriter, r *http.Request) {
	status, err := firewallService.getFirewallStatus()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(status)
}

func addPortHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		Port     int    `json:"port"`
		Protocol string `json:"protocol"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	if req.Port < 1 || req.Port > 65535 {
		http.Error(w, "端口号必须在1-65535之间", http.StatusBadRequest)
		return
	}

	if req.Protocol == "" {
		req.Protocol = "tcp"
	}

	err := firewallService.addPort(req.Port, req.Protocol)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": "端口添加成功"})
}

func removePortHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		Port     int    `json:"port"`
		Protocol string `json:"protocol"`
	}

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	if req.Protocol == "" {
		req.Protocol = "tcp"
	}

	err := firewallService.removePort(req.Port, req.Protocol)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": "端口移除成功"})
}

func enableHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	err := firewallService.enableFirewall()
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"message": "防火墙启用成功"})
}

func main() {
	// 设置路由
	http.HandleFunc("/", indexHandler)
	http.HandleFunc("/api/status", statusHandler)
	http.HandleFunc("/api/add-port", addPortHandler)
	http.HandleFunc("/api/remove-port", removePortHandler)
	http.HandleFunc("/api/enable", enableHandler)

	// 启动服务器
	fmt.Println("🛡️ 防火墙管理服务启动")
	fmt.Println("📡 访问地址: http://localhost:5555")
	fmt.Println("🔥 服务运行在端口 5555")
	
	log.Fatal(http.ListenAndServe(":5555", nil))
} 
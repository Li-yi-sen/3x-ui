#!/bin/bash

# 3X-UI 版本检查脚本
# 用于验证所有组件版本是否正确更新

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
purple='\033[0;35m'
plain='\033[0m'

echo -e "${blue}🔍 3X-UI 版本检查工具${plain}"
echo "======================================"

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 检查系统信息
echo -e "${purple}📋 系统信息${plain}"
echo "操作系统: $(cat /etc/os-release | grep "PRETTY_NAME" | cut -d '"' -f2)"
echo "架构: $(uname -m)"
echo "内核: $(uname -r)"
echo ""

# 检查Docker版本
echo -e "${purple}🐳 Docker 环境${plain}"
if command -v docker &> /dev/null; then
    docker_version=$(docker --version | awk '{print $3}' | sed 's/,//')
    echo -e "Docker: ${green}$docker_version${plain}"
else
    echo -e "Docker: ${red}未安装${plain}"
fi

if command -v docker-compose &> /dev/null; then
    compose_version=$(docker-compose --version | awk '{print $3}' | sed 's/,//')
    echo -e "Docker Compose: ${green}$compose_version${plain}"
else
    echo -e "Docker Compose: ${red}未安装${plain}"
fi
echo ""

# 检查Go版本
echo -e "${purple}🔧 Go 环境${plain}"
if command -v go &> /dev/null; then
    go_version=$(go version | awk '{print $3}')
    echo -e "Go 版本: ${green}$go_version${plain}"
    
    # 检查主项目go.mod
    if [ -f "$SCRIPT_DIR/go.mod" ]; then
        main_go_version=$(grep "^go " "$SCRIPT_DIR/go.mod" | awk '{print $2}')
        echo -e "主项目 go.mod: ${green}go $main_go_version${plain}"
    fi
    
    # 检查防火墙服务器go.mod
    if [ -f "$SCRIPT_DIR/web/firewall-server/go.mod" ]; then
        firewall_go_version=$(grep "^go " "$SCRIPT_DIR/web/firewall-server/go.mod" | awk '{print $2}')
        echo -e "防火墙服务器 go.mod: ${green}go $firewall_go_version${plain}"
    fi
else
    echo -e "Go: ${red}未安装${plain}"
fi
echo ""

# 检查Xray版本
echo -e "${purple}🚀 Xray 核心${plain}"
if [ -f "$SCRIPT_DIR/DockerInit.sh" ]; then
    xray_version=$(grep "XRAY_VERSION=" "$SCRIPT_DIR/DockerInit.sh" | cut -d '"' -f2)
    echo -e "DockerInit.sh 中的 Xray 版本: ${green}$xray_version${plain}"
fi

if [ -f "$SCRIPT_DIR/go.mod" ]; then
    xray_mod_version=$(grep "github.com/xtls/xray-core" "$SCRIPT_DIR/go.mod" | awk '{print $2}')
    echo -e "go.mod 中的 Xray 依赖: ${green}$xray_mod_version${plain}"
fi
echo ""

# 检查Docker配置
echo -e "${purple}🐳 Docker 配置${plain}"
if [ -f "$SCRIPT_DIR/docker-compose.yml" ]; then
    echo -e "docker-compose.yml: ${green}存在${plain}"
    
    # 检查版本声明
    if grep -q "version:" "$SCRIPT_DIR/docker-compose.yml"; then
        compose_file_version=$(grep "version:" "$SCRIPT_DIR/docker-compose.yml" | head -1 | awk '{print $2}' | tr -d "'\"")
        echo -e "  - Compose 文件版本: ${green}$compose_file_version${plain}"
    fi
    
    # 检查Nginx镜像版本
    if grep -q "nginx:" "$SCRIPT_DIR/docker-compose.yml"; then
        nginx_image=$(grep "image: nginx" "$SCRIPT_DIR/docker-compose.yml" | awk '{print $2}')
        echo -e "  - Nginx 镜像: ${green}$nginx_image${plain}"
    fi
    
    # 检查健康检查
    if grep -q "healthcheck:" "$SCRIPT_DIR/docker-compose.yml"; then
        echo -e "  - 健康检查: ${green}已配置${plain}"
    else
        echo -e "  - 健康检查: ${yellow}未配置${plain}"
    fi
else
    echo -e "docker-compose.yml: ${red}不存在${plain}"
fi

if [ -f "$SCRIPT_DIR/Dockerfile" ]; then
    echo -e "Dockerfile: ${green}存在${plain}"
    
    # 检查Go版本
    go_docker_version=$(grep "FROM golang:" "$SCRIPT_DIR/Dockerfile" | awk '{print $2}')
    echo -e "  - Go 构建镜像: ${green}$go_docker_version${plain}"
    
    # 检查Alpine版本
    alpine_version=$(grep "FROM alpine:" "$SCRIPT_DIR/Dockerfile" | awk '{print $2}')
    echo -e "  - Alpine 基础镜像: ${green}$alpine_version${plain}"
    
    # 检查时区设置
    if grep -q "TZ=Asia/Shanghai" "$SCRIPT_DIR/Dockerfile"; then
        echo -e "  - 时区设置: ${green}Asia/Shanghai${plain}"
    fi
else
    echo -e "Dockerfile: ${red}不存在${plain}"
fi
echo ""

# 检查防火墙服务器配置
echo -e "${purple}🛡️ 防火墙服务器${plain}"
if [ -f "$SCRIPT_DIR/web/firewall-server/Dockerfile" ]; then
    echo -e "防火墙 Dockerfile: ${green}存在${plain}"
    
    firewall_go_docker=$(grep "FROM golang:" "$SCRIPT_DIR/web/firewall-server/Dockerfile" | awk '{print $2}')
    echo -e "  - Go 构建镜像: ${green}$firewall_go_docker${plain}"
    
    firewall_alpine=$(grep "FROM alpine:" "$SCRIPT_DIR/web/firewall-server/Dockerfile" | awk '{print $2}')
    echo -e "  - Alpine 镜像: ${green}$firewall_alpine${plain}"
else
    echo -e "防火墙 Dockerfile: ${red}不存在${plain}"
fi

if [ -f "$SCRIPT_DIR/web/firewall-server/go.mod" ]; then
    echo -e "防火墙 go.mod: ${green}存在${plain}"
    
    gin_version=$(grep "github.com/gin-gonic/gin" "$SCRIPT_DIR/web/firewall-server/go.mod" | awk '{print $2}')
    if [ ! -z "$gin_version" ]; then
        echo -e "  - Gin 框架版本: ${green}$gin_version${plain}"
    else
        echo -e "  - Gin 框架版本: ${red}未找到${plain}"
    fi
else
    echo -e "防火墙 go.mod: ${red}不存在${plain}"
fi
echo ""

# 检查关键依赖版本
echo -e "${purple}📦 关键依赖版本${plain}"
if [ -f "$SCRIPT_DIR/go.mod" ]; then
    telego_version=$(grep "github.com/mymmrac/telego" "$SCRIPT_DIR/go.mod" | awk '{print $2}')
    gin_version=$(grep "github.com/gin-gonic/gin" "$SCRIPT_DIR/go.mod" | awk '{print $2}')
    
    echo -e "Telegram SDK: ${green}$telego_version${plain}"
    echo -e "Gin 框架: ${green}$gin_version${plain}"
fi
echo ""

# 检查关键脚本文件
echo -e "${purple}📜 关键脚本文件${plain}"
scripts=(
    "local-install-entry.sh"
    "start-firewall-server.sh"
    "stop-firewall-server.sh"
    "firewall-quick-start.sh"
    "DockerInit.sh"
    "DockerEntrypoint.sh"
)

for script in "${scripts[@]}"; do
    if [ -f "$SCRIPT_DIR/$script" ]; then
        if [ -x "$SCRIPT_DIR/$script" ]; then
            echo -e "$script: ${green}存在且可执行${plain}"
        else
            echo -e "$script: ${yellow}存在但不可执行${plain}"
        fi
    else
        echo -e "$script: ${red}不存在${plain}"
    fi
done
echo ""

# 检查端口配置
echo -e "${purple}🌐 端口配置${plain}"
if [ -f "$SCRIPT_DIR/docker-compose.yml" ]; then
    if grep -q "2053:2053" "$SCRIPT_DIR/docker-compose.yml"; then
        echo -e "主面板端口 (2053): ${green}已配置${plain}"
    else
        echo -e "主面板端口 (2053): ${yellow}未配置${plain}"
    fi
    
    if grep -q "5555:5555" "$SCRIPT_DIR/docker-compose.yml"; then
        echo -e "防火墙管理端口 (5555): ${green}已配置${plain}"
    else
        echo -e "防火墙管理端口 (5555): ${yellow}未配置${plain}"
    fi
fi
echo ""

# 检查文档文件
echo -e "${purple}📚 文档文件${plain}"
docs=(
    "README.md"
    "README-完整说明.md"
    "部署说明.md"
    "版本更新说明.md"
    "MD文件整合说明.md"
)

for doc in "${docs[@]}"; do
    if [ -f "$SCRIPT_DIR/$doc" ]; then
        echo -e "$doc: ${green}存在${plain}"
    else
        echo -e "$doc: ${red}不存在${plain}"
    fi
done
echo ""

# 最终评估
echo -e "${blue}📊 版本检查总结${plain}"
echo "======================================"

# 计算检查项目
total_checks=0
passed_checks=0

# Docker 环境 (2项)
total_checks=$((total_checks + 2))
if command -v docker &> /dev/null; then
    passed_checks=$((passed_checks + 1))
fi
if command -v docker-compose &> /dev/null; then
    passed_checks=$((passed_checks + 1))
fi

# Go 环境 (1项)
total_checks=$((total_checks + 1))
if command -v go &> /dev/null; then
    passed_checks=$((passed_checks + 1))
fi

# 文件存在性检查 (关键文件)
key_files=(
    "go.mod"
    "Dockerfile"
    "docker-compose.yml"
    "web/firewall-server/go.mod"
    "web/firewall-server/Dockerfile"
    "DockerInit.sh"
    "local-install-entry.sh"
)

for file in "${key_files[@]}"; do
    total_checks=$((total_checks + 1))
    if [ -f "$SCRIPT_DIR/$file" ]; then
        passed_checks=$((passed_checks + 1))
    fi
done

# 计算通过率
pass_rate=$((passed_checks * 100 / total_checks))

if [ $pass_rate -ge 90 ]; then
    echo -e "检查结果: ${green}优秀${plain} ($passed_checks/$total_checks 项通过, $pass_rate%)"
    echo -e "${green}✅ 所有关键组件版本配置正确，可以正常使用！${plain}"
elif [ $pass_rate -ge 70 ]; then
    echo -e "检查结果: ${yellow}良好${plain} ($passed_checks/$total_checks 项通过, $pass_rate%)"
    echo -e "${yellow}⚠️ 大部分组件正常，建议检查未通过的项目${plain}"
else
    echo -e "检查结果: ${red}需要修复${plain} ($passed_checks/$total_checks 项通过, $pass_rate%)"
    echo -e "${red}❌ 发现多个问题，建议修复后再使用${plain}"
fi

echo ""
echo -e "${blue}💡 使用建议${plain}"
echo "- 确保Docker和Docker Compose已正确安装"
echo "- 使用 'docker-compose up -d' 启动容器化服务"
echo "- 使用 'bash local-install-entry.sh' 进行本地化安装"
echo "- 查看 README-完整说明.md 获取详细使用指南"

echo ""
echo -e "${purple}🎉 感谢使用 3X-UI 本地化优化版本！${plain}" 
#!/bin/bash

# 3X-UI line endings fix script
# Convert all script files from Windows format (CRLF) to Unix format (LF)

red='\033[0;31m'
green='\033[0;32m'
blue='\033[0;34m'
yellow='\033[0;33m'
plain='\033[0m'

echo -e "${green}3X-UI Line Endings Fix Script${plain}"
echo -e "${blue}=====================================${plain}"

# Check if dos2unix is available
if ! command -v dos2unix &> /dev/null; then
    echo -e "${yellow}Installing dos2unix tool...${plain}"
    if command -v apt-get &> /dev/null; then
        apt-get update && apt-get install -y dos2unix
    elif command -v yum &> /dev/null; then
        yum install -y dos2unix
    elif command -v dnf &> /dev/null; then
        dnf install -y dos2unix
    elif command -v pacman &> /dev/null; then
        pacman -S --noconfirm dos2unix
    else
        echo -e "${red}Cannot install dos2unix automatically. Please install manually.${plain}"
        exit 1
    fi
fi

echo -e "\n${yellow}Starting file format conversion...${plain}"

# Convert all .sh script files
echo -e "${blue}Converting Shell script files:${plain}"
find . -name "*.sh" -type f | while read -r file; do
    echo -e "  Processing: ${file}"
    dos2unix "$file" 2>/dev/null
    chmod +x "$file"
done

# Convert all .py script files
echo -e "${blue}Converting Python script files:${plain}"
find . -name "*.py" -type f | while read -r file; do
    echo -e "  Processing: ${file}"
    dos2unix "$file" 2>/dev/null
done

# Verify conversion results
echo -e "\n${yellow}Verifying conversion results...${plain}"
for file in install.sh x-ui.sh test_install.sh DockerInit.sh DockerEntrypoint.sh; do
    if [ -f "$file" ]; then
        file_info=$(file "$file" 2>/dev/null)
        if echo "$file_info" | grep -q "CRLF"; then
            echo -e "  ${red}X ${file}: still contains CRLF${plain}"
        else
            echo -e "  ${green}V ${file}: format correct${plain}"
        fi
    fi
done

echo -e "\n${green}Line endings fix completed!${plain}"
echo -e "${yellow}All script files converted to Unix format (LF)${plain}"
echo -e "${yellow}You can now run ./install.sh normally${plain}"  

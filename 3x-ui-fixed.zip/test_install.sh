#!/bin/bash

# 3X-UI 优化版本测试脚本
# 用于验证安装和配置是否正�?
red='\033[0;31m'
green='\033[0;32m'
blue='\033[0;34m'
yellow='\033[0;33m'
plain='\033[0m'

echo -e "${green}3X-UI 优化版本测试脚本${plain}"
echo -e "${blue}==============================${plain}"

# 检查安装方�?echo -e "\n${yellow}0. 检查安装方�?..${plain}"
if [[ -d "/usr/local/x-ui/web" && -f "/usr/local/x-ui/x-ui.sh" ]]; then
    echo -e "${green}�?检测到完整的本地安�?{plain}"
else
    echo -e "${yellow}! 可能是远程安装或不完整安�?{plain}"
fi

# 检查系统信�?echo -e "\n${yellow}1. 检查系统信�?..${plain}"
echo "系统版本: $(cat /etc/os-release | grep PRETTY_NAME | cut -d '=' -f2 | tr -d '\"')"
echo "内核版本: $(uname -r)"
echo "架构: $(uname -m)"

# 检查服务状�?echo -e "\n${yellow}2. 检查服务状�?..${plain}"
if systemctl is-active --quiet x-ui; then
    echo -e "${green}�?X-UI 服务运行正常${plain}"
else
    echo -e "${red}�?X-UI 服务未运�?{plain}"
fi

if systemctl is-enabled --quiet x-ui; then
    echo -e "${green}�?X-UI 开机自启已启用${plain}"
else
    echo -e "${red}�?X-UI 开机自启未启用${plain}"
fi

# 检查端口监�?echo -e "\n${yellow}3. 检查端口监�?..${plain}"
if netstat -tlnp | grep -q ":8080"; then
    echo -e "${green}�?管理端口 8080 监听正常${plain}"
else
    echo -e "${red}�?管理端口 8080 未监�?{plain}"
fi

if netstat -tlnp | grep -q ":7891"; then
    echo -e "${green}�?服务端口 7891 监听正常${plain}"
else
    echo -e "${yellow}! 服务端口 7891 未监�?(可能未配�?${plain}"
fi

if netstat -tlnp | grep -q ":22"; then
    echo -e "${green}�?SSH端口 22 监听正常${plain}"
else
    echo -e "${red}�?SSH端口 22 未监�?{plain}"
fi

# 检查防火墙配置
echo -e "\n${yellow}4. 检查防火墙配置...${plain}"
if command -v ufw &>/dev/null; then
    if ufw status | grep -q "Status: active"; then
        echo -e "${green}�?UFW防火墙已启用${plain}"
        echo "防火墙规则："
        ufw status | grep -E "(22|8080|7891)" || echo -e "${yellow}! 未找到相关端口规�?{plain}"
    else
        echo -e "${yellow}! UFW防火墙未启用${plain}"
    fi
else
    echo -e "${yellow}! UFW防火墙未安装${plain}"
fi

# 检查配置文�?echo -e "\n${yellow}5. 检查配置文�?..${plain}"
if [ -f "/usr/local/x-ui/x-ui" ]; then
    echo -e "${green}�?主程序文件存�?{plain}"
else
    echo -e "${red}�?主程序文件不存在${plain}"
fi

if [ -f "/usr/bin/x-ui" ]; then
    echo -e "${green}�?管理脚本存在${plain}"
else
    echo -e "${red}�?管理脚本不存�?{plain}"
fi

if [ -f "/etc/systemd/system/x-ui.service" ]; then
    echo -e "${green}�?系统服务文件存在${plain}"
else
    echo -e "${red}�?系统服务文件不存�?{plain}"
fi

# 检查数据库
echo -e "\n${yellow}6. 检查数据库...${plain}"
if [ -f "/etc/x-ui/x-ui.db" ]; then
    echo -e "${green}�?数据库文件存�?{plain}"
else
    echo -e "${yellow}! 数据库文件不存在 (首次安装正常)${plain}"
fi

# 网络连接测试
echo -e "\n${yellow}7. 网络连接测试...${plain}"
local_ip=$(curl -s --max-time 3 https://api.ipify.org 2>/dev/null || echo "无法获取")
echo "外网IP: $local_ip"

if [ "$local_ip" != "无法获取" ]; then
    echo -e "${green}�?网络连接正常${plain}"
    echo -e "\n${blue}访问地址建议:${plain}"
    echo "HTTP: http://$local_ip:8080/"
    echo -e "${yellow}注意: 实际访问需要加上WebBasePath，请查看安装完成时的输出信息${plain}"
else
    echo -e "${red}�?网络连接异常${plain}"
fi

# 日志检�?echo -e "\n${yellow}8. 最近日志检�?..${plain}"
echo "最�?条系统日志："
journalctl -u x-ui --no-pager -n 5 | tail -n 5

# 总结
echo -e "\n${blue}==============================${plain}"
echo -e "${green}测试完成�?{plain}"
echo -e "\n${yellow}如果发现问题，请运行以下命令获取详细信息�?{plain}"
echo "systemctl status x-ui"
echo "journalctl -u x-ui -f"
echo "ufw status verbose"
echo "netstat -tlnp | grep -E '(8080|7891|22)'"
echo ""
echo -e "${blue}管理命令�?{plain}"
echo "x-ui                # 显示管理菜单"
echo "x-ui settings       # 查看当前配置"
echo "x-ui restart        # 重启服务"
echo ""
echo -e "${yellow}程序包下载地址�?{plain}"
echo "wget https://github.com/Li-yi-sen/3x-ui/raw/main/3x-ui.zip"  

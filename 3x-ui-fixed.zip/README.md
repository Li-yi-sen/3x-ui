[English](/README.md) | [فارسی](/README.fa_IR.md) | [العربية](/README.ar_EG.md) |  [中文](/README.zh_CN.md) | [Español](/README.es_ES.md) | [Русский](/README.ru_RU.md)

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="./media/3x-ui-dark.png">
    <img alt="3x-ui" src="./media/3x-ui-light.png">
  </picture>
</p>

[![](https://img.shields.io/github/v/release/Li-yi-sen/3x-ui.svg?style=for-the-badge)](https://github.com/Li-yi-sen/3x-ui/releases)
[![Downloads](https://img.shields.io/github/downloads/Li-yi-sen/3x-ui/total.svg?style=for-the-badge)](https://github.com/Li-yi-sen/3x-ui/releases/latest)
[![License](https://img.shields.io/badge/license-GPL%20V3-blue.svg?longCache=true&style=for-the-badge)](https://www.gnu.org/licenses/gpl-3.0.en.html)

**3X-UI Optimized** — 优化版本，专为Debian 11/12设计的稳定版本，固定端口配置，无升级功能。

> [!IMPORTANT]
> 本项目仅供个人学习使用，请勿用于非法用途，请勿在生产环境中使用。

## 优化特性

### 🔧 固定端口配置
- **8080**: 管理后台端口
- **7891**: 内部服务端口  
- **22**: SSH端口
- 端口配置固定，无法更改，确保系统稳定性

### 🛡️ 增强安全性
- 优化防火墙配置，端口开启立即生效
- 移除升级功能，避免版本冲突
- 固定版本，确保系统稳定运行

### 🐧 Debian 11/12 优化
- 完美适配Debian 11和Debian 12
- 修复glibc兼容性问题
- 优化包管理器配置

### 📦 本地化安装
- 不依赖GitHub API获取版本信息
- 从指定仓库下载安装包
- 支持离线安装部署

### ✅ 安装方式说明

#### 🎯 推荐：直接下载程序包
- **文件名**: `3x-ui2.1.zip`
- **下载链接**: https://github.com/Li-yi-sen/3x-ui/raw/main/3x-ui2.1.zip
- **优势**: 
  - ✅ 直接解压即可安装
  - ✅ 文件体积小
  - ✅ 包含编译好的程序

#### 📋 不推荐：下载完整仓库
- **下载链接**: https://github.com/Li-yi-sen/3x-ui/archive/refs/heads/main.zip
- **说明**: 这会下载整个仓库，包含源代码和程序包，需要多次解压

## 安装步骤

### 📦 本地安装（推荐）

#### 方法一：直接下载程序包
```bash
# 1. 下载编译好的程序包
wget https://github.com/Li-yi-sen/3x-ui/raw/main/3x-ui2.1.zip

# 2. 解压程序包
unzip 3x-ui2.1.zip

# 3. 进入目录执行安装
cd 3x-ui
chmod +x install.sh
sudo ./install.sh
```

#### 方法二：Git克隆后解压
```bash
# 1. 克隆项目
git clone https://github.com/Li-yi-sen/3x-ui.git

# 2. 进入目录，解压程序包
cd 3x-ui
unzip 3x-ui2.1.zip
cd 3x-ui
chmod +x install.sh
sudo ./install.sh
```

### ✅ 本地安装优势

- ✅ **无网络依赖**: 下载后可离线安装
- ✅ **安装稳定**: 不受GitHub访问限制影响  
- ✅ **速度更快**: 无需实时下载文件
- ✅ **易于调试**: 可以查看和修改安装脚本
- ✅ **版本控制**: 确保使用固定版本，避免意外更新

## 管理命令

```bash
x-ui                # 显示管理菜单
x-ui start          # 启动面板
x-ui stop           # 停止面板
x-ui restart        # 重启面板
x-ui status         # 查看状态
x-ui settings       # 查看设置
x-ui enable         # 开机自启
x-ui disable        # 取消自启
x-ui log            # 查看日志
x-ui install        # 安装面板
x-ui uninstall      # 卸载面板
```

## 固定端口说明

| 端口 | 用途 | 说明 |
|------|------|------|
| 22 | SSH | 系统SSH连接端口 |
| 8080 | 管理面板 | Web管理界面访问端口 |
| 7891 | 内部服务 | X-UI内部服务通信端口 |

## 防火墙配置

安装时会自动配置UFW防火墙，开启必要端口：

```bash
# 查看防火墙状态
ufw status

# 防火墙已自动配置以下规则：
# 22/tcp    ALLOW       SSH
# 8080/tcp  ALLOW       X-UI Management Panel  
# 7891/tcp  ALLOW       X-UI Internal Service
```

## 版本说明

此优化版本特点：
- ✅ 固定端口配置，不可更改
- ✅ 移除所有升级功能
- ✅ 优化Debian 11/12兼容性
- ✅ 修复防火墙立即生效问题
- ✅ 本地化安装，不依赖外部API
- ❌ 无版本升级功能
- ❌ 无自定义端口功能

## 支持系统

- ✅ Debian 11 (Bullseye)
- ✅ Debian 12 (Bookworm)  
- ✅ Ubuntu 20.04+
- ⚠️ 其他系统未经充分测试

## 故障排除

### 常见问题

1. **端口无法访问**
   ```bash
   # 检查防火墙状态
   ufw status
   
   # 检查服务状态
   systemctl status x-ui
   ```

2. **安装失败**
   ```bash
   # 检查系统版本
   cat /etc/os-release
   
   # 检查网络连接
   ping github.com
   ```

3. **服务无法启动**
   ```bash
   # 查看详细日志
   journalctl -u x-ui -f
   ```

## 安全建议

1. 定期更改管理员密码
2. 使用强密码和复杂的WebBasePath
3. 配置SSL证书加密传输
4. 限制管理面板访问IP
5. 定期备份配置文件

## 致谢

基于原版 [MHSanaei/3x-ui](https://github.com/MHSanaei/3x-ui) 优化改进。

## 支持项目

**如果此项目对您有帮助，请给个**:star2:

<p align="left">
  <a href="https://buymeacoffee.com/mhsanaei" target="_blank">
    <img src="./media/buymeacoffe.png" alt="Image">
  </a>
</p>

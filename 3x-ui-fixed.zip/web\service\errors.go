package service

import (
	"errors"
	"fmt"
)

// 定义服务层的标准错误
var (
	ErrInvalidInput     = errors.New("invalid input")
	ErrResourceNotFound = errors.New("resource not found")
	ErrDuplicateResource = errors.New("resource already exists")
	ErrPermissionDenied = errors.New("permission denied")
	ErrInternalError    = errors.New("internal server error")
)

// ServiceError 包装服务错误，提供更多上下文
type ServiceError struct {
	Op      string // 操作名称
	Err     error  // 原始错误
	Message string // 自定义消息
}

func (e *ServiceError) Error() string {
	if e.Message != "" {
		return fmt.Sprintf("%s: %s: %v", e.Op, e.Message, e.Err)
	}
	return fmt.Sprintf("%s: %v", e.Op, e.Err)
}

func (e *ServiceError) Unwrap() error {
	return e.Err
}

// NewServiceError 创建新的服务错误
func NewServiceError(op string, err error, message string) *ServiceError {
	return &ServiceError{
		Op:      op,
		Err:     err,
		Message: message,
	}
}

// WrapError 包装错误并添加操作上下文
func WrapError(op string, err error) error {
	if err == nil {
		return nil
	}
	return &ServiceError{
		Op:  op,
		Err: err,
	}
} 
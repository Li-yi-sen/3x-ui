package service

import (
	"x-ui/database"
	"gorm.io/gorm"
)

// BaseService 提供通用的数据库访问方法
type BaseService struct{}

// GetDB 获取数据库连接
func (s *BaseService) GetDB() *gorm.DB {
	return database.GetDB()
}

// WithTx 在事务中执行操作
func (s *BaseService) WithTx(fn func(*gorm.DB) error) error {
	tx := s.GetDB().Begin()
	if tx.Error != nil {
		return tx.Error
	}
	
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			panic(r)
		}
	}()
	
	if err := fn(tx); err != nil {
		tx.Rollback()
		return err
	}
	
	return tx.Commit().Error
} 